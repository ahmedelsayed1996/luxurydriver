<?php


function nd_travel_get_current_destination_packages() { 

    $nd_travel_destination_id = get_the_ID();
    $nd_travel_number_packages = 0;

    //get number packages number
    $nd_travel_number_packages = $nd_travel_number_packages + nd_travel_get_number_posts('nd_travel_cpt_1','nd_travel_meta_box_destinations',$nd_travel_destination_id);

    //check if the destination selected has some children destinations
    if ( count(nd_travel_get_destinations_with_parent($nd_travel_destination_id)) != 0 ){

        $nd_travel_children_destinations_array = nd_travel_get_destinations_with_parent($nd_travel_destination_id);

        foreach ($nd_travel_children_destinations_array as $nd_travel_children_destination_id) {
            
          //get parent id of children dest
          $nd_travel_parent_id_of_children_dest = get_post_meta( $nd_travel_children_destination_id, 'nd_travel_meta_box_parent_destination', true );

          if ( $nd_travel_parent_id_of_children_dest == $nd_travel_destination_id ) {
            $nd_travel_number_packages = $nd_travel_number_packages + nd_travel_get_number_posts('nd_travel_cpt_1','nd_travel_meta_box_destinations',$nd_travel_children_destination_id);
          }

        }

    }

    return $nd_travel_number_packages.' '.__('Available','nd-travel');


}

add_shortcode('nd_travel_destination_packages', 'nd_travel_get_current_destination_packages');


function nd_travel_get_current_typology_packages() { 

    $nd_travel_current_typology_id = get_the_ID();
    $nd_travel_number_packages = 0;
    $nd_travel_number_packages = $nd_travel_number_packages + nd_travel_get_number_posts('nd_travel_cpt_1','nd_travel_meta_box_typologies',$nd_travel_current_typology_id);
    return $nd_travel_number_packages.' '.__('Available','nd-travel');

}

add_shortcode('nd_travel_typology_packages', 'nd_travel_get_current_typology_packages');





/*shortcode BOOKING widget*/
function nd_travel_booking_widget_shortcode() { 

	wp_enqueue_script( 'jquery-ui-tabs');


	//get datas
	$nd_travel_meta_box_new_price = get_post_meta( get_the_ID(), 'nd_travel_meta_box_new_price', true );
	$nd_travel_meta_box_color = get_post_meta( get_the_ID(), 'nd_travel_meta_box_color', true );
	if ( $nd_travel_meta_box_color == '' ) { $nd_travel_meta_box_color = '#000'; }


	$nd_travel_price_section = '';

	//currency
    $nd_travel_currency_position = get_option('nd_travel_currency_position');
    if ( $nd_travel_currency_position == 0 ) {
        $nd_travel_currency_right_value = nd_travel_get_currency();
        $nd_travel_currency_left_value = '';
    }else{
        $nd_travel_currency_left_value = nd_travel_get_currency();
        $nd_travel_currency_right_value = '';
    }


	//BOOKING FORMS
	$nd_travel_cf7_form = '';
	$nd_travel_cf7_title = '';
	$nd_travel_meta_box_more_info_request_form = get_post_meta( get_the_ID(), 'nd_travel_meta_box_more_info_request_form', true );
	$nd_travel_meta_box_more_info_request_form_cf7 = get_post_meta( get_the_ID(), 'nd_travel_meta_box_more_info_request_form_cf7', true );

	if ( $nd_travel_meta_box_more_info_request_form == 'nd_travel_meta_box_more_info_request_form_yes'  ) {
		
		$nd_travel_cf7_title = '

		<li class=" nd_travel_float_left nd_travel_width_50_percentage"><a class="nd_travel_color_000000 nd_travel_font_size_14" href="#nd_travel_single_package_booking_tab_cf7">'.__('Enquiry Form','nd-travel').'</a></li>

		';

		$nd_travel_cf7_form .= '

		<style>

		#nd_travel_single_package_booking_tab_cf7 input[type="text"],
		#nd_travel_single_package_booking_tab_cf7 input[type="email"],
		#nd_travel_single_package_booking_tab_cf7 input[type="date"],
		#nd_travel_single_package_booking_tab_cf7 input[type="number"],
		#nd_travel_single_package_booking_tab_cf7 textarea { float:left; width:100%; box-sizing:border-box; margin:10px 0px; font-size:14px; outline:0px; color:#6e6e6e; }

		#nd_travel_single_package_booking_tab_cf7 input[type="submit"] { float:left; width:100%; box-sizing:border-box; margin-top:10px; border-width:0px; letter-spacing:1px; cursor:pointer; }

		</style>

		<div id="nd_travel_single_package_booking_tab_cf7">
			<div class="nd_travel_section nd_travel_box_sizing_border_box">
				'.do_shortcode('[contact-form-7 id="'.$nd_travel_meta_box_more_info_request_form_cf7.'"]').'
			</div>
		</div>

		';

	}


	//BOOKING Woo
	$nd_travel_woo_title = '';
	$nd_travel_woo_form = '';
	$nd_travel_meta_box_package_woo_product = get_post_meta( get_the_ID(), 'nd_travel_meta_box_package_woo_product', true );
	
	if ( $nd_travel_meta_box_package_woo_product != 0 ) {
	
		$nd_travel_woo_title .= '

		<li class=" nd_travel_float_left nd_travel_width_50_percentage nd_travel_border_right_1_solid_e4e4e4"><a class="nd_travel_color_000000 nd_travel_font_size_14" href="#nd_travel_single_package_booking_tab_woo">'.__('Booking Form','nd-travel').'</a></li>

		';

		$nd_travel_woo_form .= '

		<div id="nd_travel_single_package_booking_tab_woo">
			'.do_shortcode("[nd_travel_woo_checkout]").'
		</div>

		';

	}



	if ( $nd_travel_meta_box_new_price != 0 ) {

		$nd_travel_price_section .= '

		<div class="nd_travel_section nd_travel_margin_bottom_30">

			<div class="nd_travel_width_50_percentage nd_travel_float_left">
				<h5 class="nd_travel_margin_0 nd_travel_padding_0">'.__('Price','nd-travel').'</h5>
				<h4 class="nd_travel_margin_0 nd_travel_padding_0">'.__('From','nd-travel').'</h4>
			</div>

			<div class="nd_travel_width_50_percentage nd_travel_float_left nd_travel_text_align_right">
				<h2 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_margin_top_10"><span class="nd_travel_font_size_25">'.$nd_travel_currency_left_value.'</span> '.$nd_travel_meta_box_new_price.' <span class="nd_travel_font_size_25">'.$nd_travel_currency_right_value.'</span></h2>
			</div>

		</div>

		';

	}	


    
    $nd_travel_booking_widget = '

    <script type="text/javascript">
    //<![CDATA[
    jQuery(document).ready(function() {

        jQuery( function ( $ ) {

            $( "#nd_travel_single_package_booking_tabs" ).tabs();

            $("#nd_travel_single_package_booking_tab_cf7 .nd_travel_single_package_cf7_package_id").val("'.get_the_title().' - '.__('ID','nd-travel').' : '.get_the_ID().'");

        });

    });
    //]]>
    </script>

    <style>
    	#nd_travel_single_package_booking_tabs ul li.ui-state-active a { color:'.$nd_travel_meta_box_color.'; }
    </style>


	'.$nd_travel_price_section.'


	<div class="nd_travel_section" id="nd_travel_single_package_booking_tabs">

		<ul class="nd_travel_margin_0 nd_travel_padding_20_0 nd_travel_border_1_solid_e4e4e4 nd_travel_border_right_width_0_important nd_travel_border_left_width_0_important nd_travel_section nd_travel_list_style_none nd_travel_text_align_center">
			'.$nd_travel_woo_title.'
			'.$nd_travel_cf7_title.'
		</ul>

		'.$nd_travel_woo_form.'
		'.$nd_travel_cf7_form.'
	
	</div>

    ';



    return $nd_travel_booking_widget;

}

add_shortcode('nd_travel_booking_widget', 'nd_travel_booking_widget_shortcode');










/*shortcode WOO CHECKOUT*/
function nd_travel_package_woo_checkout() { 

	$nd_travel_id = get_the_ID();
	$nd_travel_package_price = get_post_meta( $nd_travel_id, 'nd_travel_meta_box_new_price', true );
    $nd_travel_adult_price = get_post_meta( $nd_travel_id, 'nd_travel_meta_box_new_price', true );
    $nd_travel_children_price = get_post_meta( $nd_travel_id, 'nd_travel_meta_box_children_price', true );
    $nd_travel_form_booking_price_services = 0;

    //currency
    $nd_travel_currency_position = get_option('nd_travel_currency_position');
    if ( $nd_travel_currency_position == 0 ) {
        $nd_travel_currency_right_value = nd_travel_get_currency();
        $nd_travel_currency_left_value = '';
    }else{
        $nd_travel_currency_left_value = nd_travel_get_currency();
        $nd_travel_currency_right_value = '';
    }

    //date format
    $nd_travel_date_format = get_option('nd_travel_date_format');
    if ( $nd_travel_date_format == 'm-d-Y' ) {
    	$nd_travel_date_format = 'mm-dd-yy';
    }elseif ( $nd_travel_date_format == 'd-m-Y' ) {
    	$nd_travel_date_format = 'dd-mm-yy';
    }elseif ( $nd_travel_date_format == 'Y-m-d' ) {
    	$nd_travel_date_format = 'yy-mm-dd';
    }else {
    	$nd_travel_date_format = 'yy-dd-mm';	
    }


    //date to for limit the calendar
    $nd_travel_meta_box_availability_to = get_post_meta( $nd_travel_id, 'nd_travel_meta_box_availability_to', true );
    $nd_booking_package_date_to = new DateTime($nd_travel_meta_box_availability_to);
	$nd_booking_package_date_to_new = date_format($nd_booking_package_date_to, get_option('nd_travel_date_format'));


    $nd_travel_meta_box_woo_services = get_post_meta( get_the_ID(), 'nd_travel_meta_box_woo_services', true );
    $nd_travel_package_adults = 1;
    $nd_travel_package_children = 0;


	//ajax results woo
    $nd_travel_woo_params = array(
        'nd_travel_ajaxurl_woo' => admin_url('admin-ajax.php'),
        'nd_travel_ajaxnonce_woo' => wp_create_nonce('nd_travel_woo_nonce'),
    );

    wp_enqueue_script( 'nd_travel_book_woo', esc_url( plugins_url( 'woo.js', __FILE__ ) ), array( 'jquery' ) ); 
    wp_localize_script( 'nd_travel_book_woo', 'nd_travel_my_vars_woo', $nd_travel_woo_params ); 
    //end ajax woo


    //ajax results final_price
    $nd_travel_final_price_params = array(
        'nd_travel_ajaxurl_final_price' => admin_url('admin-ajax.php'),
        'nd_travel_ajaxnonce_final_price' => wp_create_nonce('nd_travel_final_price_nonce'),
    );

    wp_enqueue_script( 'nd_travel_book_final_price', esc_url( plugins_url( 'final_price.js', __FILE__ ) ), array( 'jquery' ) ); 
    wp_localize_script( 'nd_travel_book_final_price', 'nd_travel_my_vars_final_price', $nd_travel_final_price_params ); 
    //end ajax woo


    //date picker 
    wp_enqueue_script( 'jquery-ui-datepicker');
    wp_enqueue_style('jquery-ui-datepicker-css', esc_url(plugins_url('jquery-ui-datepicker.css', __FILE__ )) );



    $nd_travel_shortcode_content .= '
    
    <form id="nd_travel_book_package_'.$nd_travel_id.'" method="post" action="'.wc_get_checkout_url().'">
      
        <!--START hidden values-->
        <input readonly type="hidden" class="nd_travel_section " name="nd_travel_form_booking_id" id="nd_travel_form_booking_id" value="'.$nd_travel_id.'">
        <input readonly type="hidden" class="nd_travel_section nd_travel_margin_top_20" name="nd_travel_form_booking_price" id="nd_travel_form_booking_price" value="'.$nd_travel_package_price.'">
        <input readonly type="hidden" class="nd_travel_section nd_travel_margin_top_20" name="nd_travel_form_booking_price_services" id="nd_travel_form_booking_price_services" value="'.$nd_travel_form_booking_price_services.'">
        <input readonly type="hidden" class="nd_travel_section nd_travel_margin_top_20" name="nd_travel_form_booking_adults" id="nd_travel_form_booking_adults" value="'.$nd_travel_package_adults.'">
        <input readonly type="hidden" class="nd_travel_section nd_travel_margin_top_20" name="nd_travel_form_booking_children" id="nd_travel_form_booking_children" value="'.$nd_travel_package_children.'">
        <input readonly type="hidden" class="nd_travel_section nd_travel_margin_top_20" name="nd_travel_form_booking_services" id="nd_travel_form_booking_services" value="">
        <!--END hidden values-->



        <!--START DATE-->
        <div class="nd_travel_section nd_travel_padding_20_0">
            <h4 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_16_important nd_travel_margin_top_10">'.__('Date','nd-travel').'</h4>
            <input name="nd_travel_form_booking_date" type="text" class="nd_travel_section nd_travel_cursor_pointer nd_travel_color_6e6e6e nd_travel_font_family_poppins nd_travel_border_width_0_important nd_travel_padding_0_important nd_travel_font_size_14 nd_travel_margin_top_5" id="nd_travel_form_booking_date" value="'.date(get_option('nd_travel_date_format')).'">
            <script type="text/javascript">
              //<![CDATA[
              jQuery(document).ready(function() {

                jQuery( function ( $ ) {

                    $( "#nd_travel_form_booking_date" ).datepicker({ 

                    	beforeShow: function( input, inst){
			              $(inst.dpDiv).addClass("nd_travel_single_package_page_calendar");
			            },

						monthNames: ["'.__('January','nd-travel').'","'.__('February','nd-travel').'","'.__('March','nd-travel').'","'.__('April','nd-travel').'","'.__('May','nd-travel').'","'.__('June','nd-travel').'", "'.__('July','nd-travel').'","'.__('August','nd-travel').'","'.__('September','nd-travel').'","'.__('October','nd-travel').'","'.__('November','nd-travel').'","'.__('December','nd-travel').'"],
						monthNamesShort: [ "'.__('Jan','nd-travel').'", "'.__('Feb','nd-travel').'", "'.__('Mar','nd-travel').'", "'.__('Apr','nd-travel').'", "'.__('May','nd-travel').'", "'.__('Jun','nd-travel').'", "'.__('Jul','nd-travel').'", "'.__('Aug','nd-travel').'", "'.__('Sep','nd-travel').'", "'.__('Oct','nd-travel').'", "'.__('Nov','nd-travel').'", "'.__('Dec','nd-travel').'" ],
						dayNamesMin: ["'.__('SU','nd-travel').'","'.__('MO','nd-travel').'","'.__('TU','nd-travel').'","'.__('WE','nd-travel').'","'.__('TH','nd-travel').'","'.__('FR','nd-travel').'", "'.__('SA','nd-travel').'"],
						nextText: "'.__('NEXT','nd-travel').'",
						prevText: "'.__('PREV','nd-travel').'",

                        dateFormat: "'.$nd_travel_date_format.'",
                        minDate: 0, 
                        maxDate: "'.$nd_booking_package_date_to_new.'" 

                    });

                });

              });
              //]]>
            </script>
        </div>
        <!--END DATE-->


        <!--START GUESTS-->
        <div class="nd_travel_bg_grey_3 nd_travel_height_1 nd_travel_section"></div>

        <div class="nd_travel_section nd_travel_padding_20_0 nd_travel_display_table">
            
            <div class=" nd_travel_width_50_percentage nd_travel_display_table_cell nd_travel_vertical_align_middle">
                <h4 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_16_important">'.__('Adults','nd-travel').'</h4>
                <p class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_14 nd_travel_margin_top_5">'.__('Over 18','nd-travel').' ( '.$nd_travel_currency_left_value.' '.$nd_travel_adult_price.' '.$nd_travel_currency_right_value.' )</p>
            </div>
            
            <div class=" nd_travel_width_50_percentage nd_travel_text_align_right nd_travel_display_table_cell nd_travel_vertical_align_middle">    
                <i class="fa fa-plus nd_travel_float_right nd_travel_line_height_35_important nd_travel_cursor_pointer nd_travel_adult_number_increase nd_travel_font_size_10" aria-hidden="true"></i>
                <h3 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_float_right nd_travel_line_height_35_important nd_travel_margin_0_20 nd_travel_adult_number">'.$nd_travel_package_adults.'</h3>
                <i class="fa fa-minus nd_travel_float_right nd_travel_line_height_35_important nd_travel_cursor_pointer nd_travel_adult_number_decrease nd_travel_font_size_10" aria-hidden="true"></i>
            </div>
            
        </div>

        
        <div class="nd_travel_bg_grey_3 nd_travel_height_1 nd_travel_section"></div>

        <div class="nd_travel_section nd_travel_padding_20_0 nd_travel_display_table">
            
            <div class=" nd_travel_width_50_percentage nd_travel_display_table_cell nd_travel_vertical_align_middle">
                <h4 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_16_important">'.__('Children','nd-travel').'</h4>
                <p class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_14 nd_travel_margin_top_5">'.__('Under 18','nd-travel').' ( '.$nd_travel_currency_left_value.' '.$nd_travel_children_price.' '.$nd_travel_currency_right_value.' )</p>
            </div>
            
            <div class=" nd_travel_width_50_percentage nd_travel_text_align_right nd_travel_display_table_cell nd_travel_vertical_align_middle">    
                <i class="fa fa-plus nd_travel_float_right nd_travel_line_height_35_important nd_travel_cursor_pointer nd_travel_children_number_increase nd_travel_font_size_10" aria-hidden="true"></i>
                <h3 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_float_right nd_travel_line_height_35_important nd_travel_margin_0_20 nd_travel_children_number">'.$nd_travel_package_children.'</h3>
                <i class="fa fa-minus nd_travel_float_right nd_travel_line_height_35_important nd_travel_cursor_pointer nd_travel_children_number_decrease nd_travel_font_size_10" aria-hidden="true"></i>
            </div>
            
        </div>

        <div class="nd_travel_bg_grey_3 nd_travel_height_1 nd_travel_section"></div>



        <script type="text/javascript">
        //<![CDATA[
        jQuery(document).ready(function() {

            jQuery( function ( $ ) {

                $(".nd_travel_children_number_increase").click(function() {
                    var value = $("#nd_travel_form_booking_children").val();
                    value++;
                    $(".nd_travel_children_number").text(value);
                    $("#nd_travel_form_booking_children").val(value);

                    nd_travel_update_booking_price();

                }); 

                $(".nd_travel_children_number_decrease").click(function() {
                    var value = $("#nd_travel_form_booking_children").val();

                    if ( value > 0 ) {
                        value--;
                        $(".nd_travel_children_number").text(value);
                        $("#nd_travel_form_booking_children").val(value);
                    }

                    nd_travel_update_booking_price();

                });


                $(".nd_travel_adult_number_increase").click(function() {
                    var value = $("#nd_travel_form_booking_adults").val();
                    value++;
                    $(".nd_travel_adult_number").text(value);
                    $("#nd_travel_form_booking_adults").val(value);

                    nd_travel_update_booking_price();

                }); 

                $(".nd_travel_adult_number_decrease").click(function() {
                    var value = $("#nd_travel_form_booking_adults").val();

                    if ( value > 1 ) {
                        value--;
                        $(".nd_travel_adult_number").text(value);
                        $("#nd_travel_form_booking_adults").val(value);
                    }

                    nd_travel_update_booking_price();

                });

            });

        });
        //]]>
        </script>
        <!--END GUESTS-->



        <!--START SERVICES-->';
        if ( $nd_travel_meta_box_woo_services != '' ) {


            $nd_travel_meta_box_woo_services_array = explode(',', get_post_meta( $nd_travel_id, 'nd_travel_meta_box_woo_services', true ) );


            $nd_travel_shortcode_content .= '
            <div class="nd_travel_section nd_travel_padding_20_0">


                <script type="text/javascript">
                //<![CDATA[
                jQuery(document).ready(function() {

                    jQuery( function ( $ ) {

                        $( ".nd_travel_booking_checkbox_service" ).change(function() {

                            if ( $( this ).is( ":checked" ) ) {

                                var nd_travel_booking_checkbox_service = $( this ).val();
                                var nd_travel_form_booking_price_services = $("#nd_travel_form_booking_price_services").val();
                                
                                var nd_travel_form_booking_new_price = parseInt(nd_travel_form_booking_price_services) + parseInt(nd_travel_booking_checkbox_service);
                                $("#nd_travel_form_booking_price_services").val(nd_travel_form_booking_new_price);

                                var nd_travel_booking_service_id = $(this).attr("data-id");
                                var nd_travel_service_previous_value = $("#nd_travel_form_booking_services").val();
                                $( "#nd_travel_form_booking_services" ).val( nd_travel_booking_service_id+nd_travel_service_previous_value );

                            }else{

                                var nd_travel_booking_checkbox_service = $( this ).val();
                                var nd_travel_form_booking_price_services = $("#nd_travel_form_booking_price_services").val();

                                var nd_travel_form_booking_new_price = parseInt(nd_travel_form_booking_price_services) - parseInt(nd_travel_booking_checkbox_service);
                                $("#nd_travel_form_booking_price_services").val(nd_travel_form_booking_new_price);

                                var nd_travel_booking_service_id = $(this).attr("data-id");
                                var nd_travel_service_previous_value = $("#nd_travel_form_booking_services").val();
                                var nd_travel_form_booking_services_new_value = nd_travel_service_previous_value.replace(nd_travel_booking_service_id, "");
                                $( "#nd_travel_form_booking_services" ).val(nd_travel_form_booking_services_new_value);

                            }

                            nd_travel_update_button_price();

                        });

                    });

                });
                //]]>
                </script>

            
                <div class="nd_travel_section">
                    <h4 class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_16_important">'.__('Extra Services','nd-travel').'</h4>
                    <p class="nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_14 nd_travel_margin_top_5 nd_travel_margin_bottom_10">'.__('Add extra services on your reservation','nd-travel').'</p>
                </div>
                
                <div class="nd_travel_section">'; 


                    //START CICLE
                    for ( $nd_travel_meta_box_woo_services_array_i = 0; $nd_travel_meta_box_woo_services_array_i < count($nd_travel_meta_box_woo_services_array)-1; $nd_travel_meta_box_woo_services_array_i++) {
                        
                        $nd_travel_page_by_path = get_page_by_path($nd_travel_meta_box_woo_services_array[$nd_travel_meta_box_woo_services_array_i],OBJECT,'product');
                        
                        //info package
                        $nd_travel_woo_service_id = $nd_travel_page_by_path->ID;
                        $nd_travel_woo_service_name = get_the_title($nd_travel_woo_service_id);
                        $nd_travel_woo_service_permalink = get_permalink($nd_travel_woo_service_id);

                        //price woo
                        $nd_travel_woo_product = wc_get_product( $nd_travel_woo_service_id );                        
                        $nd_travel_woo_service_price = $nd_travel_woo_product->get_price();

                        $nd_travel_shortcode_content .= '
                        <div class="nd_travel_section nd_travel_margin_top_10">
                            <input data-id="'.$nd_travel_woo_service_id.'," class="nd_travel_float_left nd_travel_booking_checkbox_service" type="checkbox" id="" name="" value="'.$nd_travel_woo_service_price.'">
                            <p class="nd_travel_float_left nd_travel_margin_left_15 nd_travel_margin_0 nd_travel_padding_0 nd_travel_font_size_14">'.$nd_travel_woo_service_name.' ( '.$nd_travel_currency_left_value.' '.$nd_travel_woo_service_price.' '.$nd_travel_currency_right_value.' )</p>
                        </div>
                        '; 
                
                    }   
                    //END CICLE


            $nd_travel_shortcode_content .= '
                </div>
            </div>
            '; 


        }
        $nd_travel_shortcode_content .= '
        <!--END SERVICES-->



        <input class="nd_travel_section nd_travel_display_none nd_travel_margin_top_20" type="submit" value="book">
    
    </form>

    <button id="nd_travel_woo_checkout_button" class="nd_travel_width_100_percentage nd_travel_border_width_0 nd_travel_cursor_pointer nd_travel_margin_top_10 nd_travel_font_family_poppins nd_travel_letter_spacing_1_important" onclick="nd_travel_woo_checkout()">'.__('BOOK NOW FOR','nd-travel').' '.$nd_travel_currency_left_value.' <span id="nd_travel_woo_checkout_button_price">'.$nd_travel_package_price.'</span> '.$nd_travel_currency_right_value.'</button>
    ';




    return $nd_travel_shortcode_content;

}

add_shortcode('nd_travel_woo_checkout', 'nd_travel_package_woo_checkout');





//START ajax function for woo go to the woo checkout with the product in the cart and price passed
function nd_travel_woo_php() {

    check_ajax_referer( 'nd_travel_woo_nonce', 'nd_travel_woo_security' );

    //get datas
    $nd_travel_trip_price = sanitize_text_field($_GET['nd_travel_trip_price']);
    $nd_travel_rid = sanitize_text_field($_GET['nd_travel_rid']);
    $nd_travel_services = sanitize_text_field($_GET['nd_travel_services']);

    //post data
    $nd_travel_meta_box_package_woo_product = get_post_meta( $nd_travel_rid, 'nd_travel_meta_box_package_woo_product', true );

    //clear cart
    WC()->cart->empty_cart();

    //add to cart the product
    WC()->cart->add_to_cart($nd_travel_meta_box_package_woo_product);    
    //set the price
    $nd_travel_product = wc_get_product($nd_travel_meta_box_package_woo_product);
    $nd_travel_product->set_regular_price($nd_travel_trip_price);
    $nd_travel_product->set_price($nd_travel_trip_price);
    $nd_travel_product->save();

    //add services seclected on cart
    if ( $nd_travel_services != '' ) {

        $nd_travel_services_array = explode(',', $nd_travel_services );

        for ($nd_travel_services_array_i = 0; $nd_travel_services_array_i < count($nd_travel_services_array)-1; $nd_travel_services_array_i++) {

            $nd_travel_service_id = $nd_travel_services_array[$nd_travel_services_array_i];
            WC()->cart->add_to_cart($nd_travel_service_id);

        }

    }

    $nd_travel_book_package_woo_id = 'nd_travel_book_package_'.$nd_travel_rid;
    echo esc_attr($nd_travel_book_package_woo_id);

    die();

}
add_action( 'wp_ajax_nd_travel_woo_php', 'nd_travel_woo_php' );
add_action( 'wp_ajax_nopriv_nd_travel_woo_php', 'nd_travel_woo_php' );




//START function for AJAX final price
function nd_travel_final_price_php() {

    check_ajax_referer( 'nd_travel_final_price_nonce', 'nd_travel_final_price_security' );

    //recover var
    $nd_travel_id = sanitize_text_field($_GET['nd_travel_form_booking_id']);
    $nd_travel_form_booking_price = sanitize_text_field($_GET['nd_travel_form_booking_price']);
    $nd_travel_adults_number = sanitize_text_field($_GET['nd_travel_form_booking_adults']);
    $nd_travel_children_number = sanitize_text_field($_GET['nd_travel_form_booking_children']);


    
    
    //recover post datas
    $nd_travel_adult_price = get_post_meta( $nd_travel_id, 'nd_travel_meta_box_new_price', true );
    $nd_travel_children_price = get_post_meta( $nd_travel_id, 'nd_travel_meta_box_children_price', true );


    //START CALC PRICE
    $nd_travel_final_price = 0;
    $nd_travel_adults_tot_price = $nd_travel_adult_price * $nd_travel_adults_number;
    $nd_travel_children_tot_price = $nd_travel_children_price * $nd_travel_children_number;
    $nd_travel_final_price = $nd_travel_adults_tot_price + $nd_travel_children_tot_price;
    //END CALC PRICE

    echo esc_html($nd_travel_final_price);

    die();

}
add_action( 'wp_ajax_nd_travel_final_price_php', 'nd_travel_final_price_php' );
add_action( 'wp_ajax_nopriv_nd_travel_final_price_php', 'nd_travel_final_price_php' );







//custom content in thankyou page when the order is already processed
add_action( 'woocommerce_thankyou', 'nd_travel_woo_thankyou_content', 10, 1 );
function nd_travel_woo_thankyou_content( $order_id ) {

    //$nd_travel_woo_order = new WC_Order( $order_id );
    $nd_travel_woo_order = wc_get_order( $order_id );

    //all datas
    $nd_travel_form_booking_id = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_id', true ));
    $nd_travel_form_booking_name = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_name', true ));
    $nd_travel_form_booking_date = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_date', true ));
    $nd_travel_form_booking_adults = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_adults', true ));
    $nd_travel_form_booking_children = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_children', true ));
    if ( $nd_travel_form_booking_children == '' ) { $nd_travel_form_booking_children = '0'; }
    $nd_travel_form_booking_price_adults = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_price_adults', true ));
    $nd_travel_form_booking_price_children = sanitize_text_field(get_post_meta( $order_id, 'nd_travel_form_booking_price_children', true ));
    if ( $nd_travel_form_booking_price_children == '' ) { $nd_travel_form_booking_price_children = '0'; }

    //currency
    $nd_travel_currency_position = get_option('nd_travel_currency_position');
    if ( $nd_travel_currency_position == 0 ) {
        $nd_travel_currency_right_value = nd_travel_get_currency();
        $nd_travel_currency_left_value = '';
    }else{
        $nd_travel_currency_left_value = nd_travel_get_currency();
        $nd_travel_currency_right_value = '';
    }
    
    if ( $nd_travel_form_booking_id != '' ) {

        //image
        $nd_travel_image_id = get_post_thumbnail_id( $nd_travel_form_booking_id );
        $nd_travel_image_attributes = wp_get_attachment_image_src( $nd_travel_image_id, 'full' );


        $nd_travel_result_woo_info = '
        <div id="nd_travel_custom_checkout_thank_package_fields">
            
            <h2 class="nd_travel_margin_top_40_important nd_travel_margin_bottom_30_important">'. __('Package Informations','nd-travel').'</h2>

            <div class="nd_travel_section">

                <div class="nd_travel_width_25_percentage nd_travel_width_100_percentage_responsive nd_travel_float_left nd_travel_box_sizing_border_box">
                    <img alt="'.$nd_travel_form_booking_date.'" class="nd_travel_section nd_travel_border_radius_15_important" src="'.$nd_travel_image_attributes[0].'">
                </div>

                <div class="nd_travel_width_75_percentage nd_travel_width_100_percentage_responsive nd_travel_float_left nd_travel_box_sizing_border_box nd_travel_padding_10_40 nd_travel_padding_0_responsive nd_travel_margin_top_20_responsive">

                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0 nd_travel_border_bottom_1_solid_grey"><span class="nd_travel_color_000000 ">'. __('Package','nd-travel').' :</span> '.$nd_travel_form_booking_name.' ( ID : '.$nd_travel_form_booking_id.' )</p>
                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0 nd_travel_border_bottom_1_solid_grey"><span class="nd_travel_color_000000">'. __('Date','nd-travel').' :</span> '.$nd_travel_form_booking_date.'</p>
                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0 nd_travel_border_bottom_1_solid_grey"><span class="nd_travel_color_000000">'. __('Adults','nd-travel').' :</span> '.$nd_travel_form_booking_adults.' ( '.$nd_travel_currency_left_value.' '.$nd_travel_form_booking_price_adults.' '.$nd_travel_currency_right_value.' '.__('per person','nd-travel').' )</p>
                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0"><span class="nd_travel_color_000000">'. __('Children','nd-travel').' :</span> '.$nd_travel_form_booking_children.' ( '.$nd_travel_currency_left_value.' '.$nd_travel_form_booking_price_children.' '.$nd_travel_currency_right_value.' '.__('per child','nd-travel').' )</p>

                </div>


            </div>

        </div>
        ';

        $nd_travel_allowed_html = [
            'div' => [ 
                'id' => [],
                'class' => [], 
            ],
            'img' => [ 
                'alt' => [],
                'class' => [], 
                'src' => [], 
            ],
            'h2' => [],
            'h3' => [ 
                'class' => [], 
            ],
            'p' => [ 
                'class' => [], 
            ],
            'br' => [],
            'span' => [ 
                'class' => [], 
            ],

        ];

        echo wp_kses( $nd_travel_result_woo_info, $nd_travel_allowed_html );

    }


}


//insert package custom fields passed on woo chekout page
add_action( 'woocommerce_after_order_notes', 'nd_travel_custom_checkout_package_fields' );
function nd_travel_custom_checkout_package_fields( $checkout ) {

    $nd_travel_id_package_passed = $checkout->get_value('nd_travel_form_booking_id');
    $nd_travel_name_passed = get_the_title($nd_travel_id_package_passed);
    $nd_travel_adults_passed = $checkout->get_value('nd_travel_form_booking_adults');
    $nd_travel_children_passed = $checkout->get_value('nd_travel_form_booking_children');
    if ( $nd_travel_children_passed == '' ) { $nd_travel_children_passed = '0'; }
    $nd_travel_date_passed = $checkout->get_value('nd_travel_form_booking_date');

    $nd_travel_adult_price = get_post_meta( $nd_travel_id_package_passed, 'nd_travel_meta_box_new_price', true );
    $nd_travel_children_price = get_post_meta( $nd_travel_id_package_passed, 'nd_travel_meta_box_children_price', true );


    //currency
    $nd_travel_currency_position = get_option('nd_travel_currency_position');
    if ( $nd_travel_currency_position == 0 ) {
        $nd_travel_currency_right_value = nd_travel_get_currency();
        $nd_travel_currency_left_value = '';
    }else{
        $nd_travel_currency_left_value = nd_travel_get_currency();
        $nd_travel_currency_right_value = '';
    }


    if ( $nd_travel_id_package_passed != '' ) {


        //image
        $nd_travel_image_id = get_post_thumbnail_id( $nd_travel_id_package_passed );
        $nd_travel_image_attributes = wp_get_attachment_image_src( $nd_travel_image_id, 'full' );



        $nd_travel_custom_checkout_package_info = '
        
        <div id="nd_travel_custom_checkout_package_fields">
            
            <h3 class="nd_travel_margin_top_40_important nd_travel_margin_bottom_30_important">'. __('Package Informations','nd-travel').'</h3>

            <div class="nd_travel_section">

                <div class="nd_travel_width_50_percentage nd_travel_width_100_percentage_responsive nd_travel_float_left nd_travel_box_sizing_border_box">
                    <img alt="'.$nd_travel_date_passed.'" class="nd_travel_section nd_travel_border_radius_15_important" src="'.$nd_travel_image_attributes[0].'">
                </div>

                <div class="nd_travel_width_50_percentage nd_travel_width_100_percentage_responsive nd_travel_float_left nd_travel_box_sizing_border_box nd_travel_padding_10_40 nd_travel_padding_0_responsive nd_travel_margin_top_20_responsive">

                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0 nd_travel_border_bottom_1_solid_grey"><span class="nd_travel_color_000000 ">'. __('Package','nd-travel').' :</span> '.$nd_travel_name_passed.' ( ID : '.$nd_travel_id_package_passed.' )</p>
                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0 nd_travel_border_bottom_1_solid_grey"><span class="nd_travel_color_000000">'. __('Date','nd-travel').' :</span> '.$nd_travel_date_passed.'</p>
                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0 nd_travel_border_bottom_1_solid_grey"><span class="nd_travel_color_000000">'. __('Adults','nd-travel').' :</span> '.$nd_travel_adults_passed.' ( '.$nd_travel_currency_left_value.' '.$nd_travel_adult_price.' '.$nd_travel_currency_right_value.' '.__('per person','nd-travel').' )</p>
                    <p class="nd_travel_font_family_poppins nd_travel_margin_0 nd_travel_color_6e6e6e nd_travel_font_size_14 nd_travel_padding_15_0"><span class="nd_travel_color_000000">'. __('Children','nd-travel').' :</span> '.$nd_travel_children_passed.' ( '.$nd_travel_currency_left_value.' '.$nd_travel_children_price.' '.$nd_travel_currency_right_value.' '.__('per child','nd-travel').' )</p>

                </div>


            </div>




            

        ';


        $nd_travel_allowed_html = [
            'div' => [ 
                'id' => [],
                'class' => [], 
            ],
            'img' => [ 
                'alt' => [],
                'class' => [], 
                'src' => [], 
            ],
            'h2' => [],
            'h3' => [ 
                'class' => [], 
            ],
            'p' => [ 
                'class' => [], 
            ],
            'br' => [],
            'span' => [ 
                'class' => [], 
            ],
        ];

        echo wp_kses( $nd_travel_custom_checkout_package_info, $nd_travel_allowed_html );

        woocommerce_form_field( 'nd_travel_form_booking_id', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_id_package_passed );

        woocommerce_form_field( 'nd_travel_form_booking_name', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_name_passed );

        woocommerce_form_field( 'nd_travel_form_booking_date', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_date_passed );

        woocommerce_form_field( 'nd_travel_form_booking_adults', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_adults_passed );

        woocommerce_form_field( 'nd_travel_form_booking_children', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_children_passed );

        woocommerce_form_field( 'nd_travel_form_booking_price_adults', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_adult_price );

        woocommerce_form_field( 'nd_travel_form_booking_price_children', array(
            'type'          => 'hidden',
            'class'         => array('my-field-class form-row-wide nd_travel_margin_0_important nd_travel_padding_0_important'),
        ), $nd_travel_children_price );

        $nd_travel_custom_checkout_package_info_close = '</div>';

        $nd_travel_allowed_html = [
            'div' => [ 
                'id' => [], 
            ],
        ];

        echo wp_kses( $nd_travel_custom_checkout_package_info_close, $nd_travel_allowed_html );

    }

}


//check if the new mandatory fields are filled 
add_action('woocommerce_checkout_process', 'nd_travel_custom_checkout_package_fields_process');
function nd_travel_custom_checkout_package_fields_process() {

    if ( $_POST['nd_travel_form_booking_id'] != '') {

        if ( ! $_POST['nd_travel_form_booking_id'] )
        wc_add_notice( __( 'Id Package is mandatory' ), 'error' );

        if ( ! $_POST['nd_travel_form_booking_name'] )
        wc_add_notice( __( 'Name is mandatory' ), 'error' );

        if ( ! $_POST['nd_travel_form_booking_date'] )
        wc_add_notice( __( 'Date is mandatory' ), 'error' );

        if ( ! $_POST['nd_travel_form_booking_adults'] )
        wc_add_notice( __( 'Adults is mandatory' ), 'error' );

        if ( ! $_POST['nd_travel_form_booking_price_adults'] )
        wc_add_notice( __( 'Adults Price is mandatory' ), 'error' );
        
    }
    
}


//save metabox
add_action( 'woocommerce_checkout_update_order_meta', 'nd_travel_custom_checkout_package_fields_update' );
function nd_travel_custom_checkout_package_fields_update( $order_id ) {
    
    if ( ! empty( $_POST['nd_travel_form_booking_id'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_id', sanitize_text_field( $_POST['nd_travel_form_booking_id'] ) );
    }

    if ( ! empty( $_POST['nd_travel_form_booking_name'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_name', sanitize_text_field( $_POST['nd_travel_form_booking_name'] ) );
    }

    if ( ! empty( $_POST['nd_travel_form_booking_date'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_date', sanitize_text_field( $_POST['nd_travel_form_booking_date'] ) );
    }

    if ( ! empty( $_POST['nd_travel_form_booking_adults'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_adults', sanitize_text_field( $_POST['nd_travel_form_booking_adults'] ) );
    }

    if ( ! empty( $_POST['nd_travel_form_booking_children'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_children', sanitize_text_field( $_POST['nd_travel_form_booking_children'] ) );
    }

    if ( ! empty( $_POST['nd_travel_form_booking_price_adults'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_price_adults', sanitize_text_field( $_POST['nd_travel_form_booking_price_adults'] ) );
    }

    if ( ! empty( $_POST['nd_travel_form_booking_price_children'] ) ) {
        update_post_meta( $order_id, 'nd_travel_form_booking_price_children', sanitize_text_field( $_POST['nd_travel_form_booking_price_children'] ) );
    }

}

//show the fields in admin
add_action( 'woocommerce_admin_order_data_after_billing_address', 'nd_travel_custom_checkout_package_fields_admin_order', 10, 1 );
function nd_travel_custom_checkout_package_fields_admin_order($order_id){

    if ( get_post_meta($order_id->id,'nd_travel_form_booking_id',true) != '' ) {


        $nd_travel_form_booking_children = get_post_meta( $order_id->id, 'nd_travel_form_booking_children', true );
        if ( $nd_travel_form_booking_children == '' ) { $nd_travel_form_booking_children = '0'; }

        $nd_travel_form_booking_price_children = get_post_meta( $order_id->id, 'nd_travel_form_booking_price_children', true );
        if ( $nd_travel_form_booking_price_children == '' ) { $nd_travel_form_booking_price_children = '0'; }


        if ( $nd_travel_form_booking_price_children == '' ) { $nd_travel_form_booking_price_children = '0'; }


        $nd_travel_allowed_html = [
            'p' => [],
            'strong' => [],
        ];

        //currency
        $nd_travel_currency_position = get_option('nd_travel_currency_position');
        if ( $nd_travel_currency_position == 0 ) {
            $nd_travel_currency_right_value = nd_travel_get_currency();
            $nd_travel_currency_left_value = '';
        }else{
            $nd_travel_currency_left_value = nd_travel_get_currency();
            $nd_travel_currency_right_value = '';
        }

        $nd_travel_woo_fields_admin_order_id = '

        <p><strong>'.__('Id Package').':</strong> ' . get_post_meta( $order_id->id, 'nd_travel_form_booking_id', true ) . '</p>
        <p><strong>'.__('Name Package').':</strong> ' . get_post_meta( $order_id->id, 'nd_travel_form_booking_name', true ) . '</p>
        <p><strong>'.__('Date').':</strong> ' . get_post_meta( $order_id->id, 'nd_travel_form_booking_date', true ) . '</p>
        <p><strong>'.__('Adults').':</strong> ' . get_post_meta( $order_id->id, 'nd_travel_form_booking_adults', true ) . '</p>
        <p><strong>'.__('Children').':</strong> '.$nd_travel_form_booking_children.'</p>
        <p><strong>'.__('Price Adults').':</strong> '.$nd_travel_currency_left_value.' '.get_post_meta( $order_id->id, 'nd_travel_form_booking_price_adults', true ).' '.$nd_travel_currency_right_value.'</p>
        <p><strong>'.__('Price Children').':</strong> '.$nd_travel_currency_left_value.' '.$nd_travel_form_booking_price_children.' '.$nd_travel_currency_right_value.'</p>

        ';

        echo wp_kses( $nd_travel_woo_fields_admin_order_id, $nd_travel_allowed_html );


    }
    
}
//END woo




