<?php


//START ELEMENT POST GRID
class nd_travel_packages_element extends \Elementor\Widget_Base {

  public function get_name() { return 'packages'; }
  public function get_title() { return __( 'packages', 'nd-travel' ); }
  public function get_icon() { return 'fa fa-plane'; }
  public function get_categories() { return [ 'nd-travel' ]; }

  /*START CONTROLS*/
  protected function _register_controls() {

    /*Create Tab*/
    $this->start_controls_section(
      'content_section',
      [
        'label' => __( 'Main Options', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->add_control(
      'packages_layout',
      [
        'label' => __( 'Layout', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'layout-1',
        'options' => [
          'layout-1'  => __( 'Layout 1', 'nd-travel' ),
        ],
      ]
    );

    $this->add_control(
      'packages_width',
      [
        'label' => __( 'Width', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'nd_travel_width_100_percentage',
        'options' => [
          'nd_travel_width_100_percentage'  => __( '1 Column', 'nd-travel' ),
          'nd_travel_width_50_percentage' => __( '2 Columns', 'nd-travel' ),
          'nd_travel_width_33_percentage'  => __( '3 Columns', 'nd-travel' ),
          'nd_travel_width_25_percentage' => __( '4 Columns', 'nd-travel' ),
        ],
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Image_Size::get_type(),
      [
        'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
        'exclude' => [ 'custom' ],
        'include' => [],
        'default' => 'large',
      ]
    );

    $this->add_control(
      'packages_order',
      [
        'label' => __( 'Order', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'DESC',
        'options' => [
          'DESC'  => __( 'DESC', 'nd-travel' ),
          'ASC' => __( 'ASC', 'nd-travel' ),
        ],
      ]
    );

    $this->add_control(
      'packages_orderby',
      [
        'label' => __( 'Order By', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'date',
        'options' => [
          'ID'  => __( 'ID', 'nd-travel' ),
          'author' => __( 'Author', 'nd-travel' ),
          'title'  => __( 'Title', 'nd-travel' ),
          'name' => __( 'Name', 'nd-travel' ),
          'type'  => __( 'Type', 'nd-travel' ),
          'date' => __( 'Date', 'nd-travel' ),
          'modified'  => __( 'Modified', 'nd-travel' ),
          'rand' => __( 'Random', 'nd-travel' ),
          'comment_count'  => __( 'Comment Count', 'nd-travel' ),
        ],
      ]
    );

    $this->add_control(
      'packages_qnt',
      [
        'label' => __( 'Posts Per Page', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => -1,
        'max' => 20,
        'step' => 1,
        'default' => 3,
      ]
    );


    $this->add_control(
      'packages_id',
      [
        'label' => __( 'ID', 'nd-elements' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 1,
        'max' => 9000,
        'step' => 1,
      ]
    );


    $this->add_control(
      'destination_id',
      [
        'label' => __( 'Destination ID', 'nd-elements' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 9000,
        'step' => 1,
      ]
    );


    $this->add_control(
      'typology_slug',
      [
        'label' => __( 'Typology Slug', 'nd-elements' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'min' => 0,
        'max' => 9000,
        'step' => 1,
      ]
    );
    
    $this->end_controls_section();

  }
  //END CONTROLS


 
  /*START RENDER*/
  protected function render() {

    $nd_travel_result = '';

    //add script
    wp_enqueue_script('masonry');
    wp_enqueue_script('nd_travel_elementor_packages_js', esc_url( plugins_url('js/packages.js', __FILE__ )) );
    wp_enqueue_script('jquery-ui-dialog');

    //get datas
    $nd_travel_settings = $this->get_settings_for_display();
    $nd_travel_postgrid_order = $nd_travel_settings['packages_order'];
    $nd_travel_postgrid_orderby = $nd_travel_settings['packages_orderby'];
    $packages_qnt = $nd_travel_settings['packages_qnt'];
    $packages_width = $nd_travel_settings['packages_width'];
    $packages_layout = $nd_travel_settings['packages_layout'];
    $packages_id = $nd_travel_settings['packages_id'];
    $nd_travel_destination_id = $nd_travel_settings['destination_id'];
    $nd_travel_typology_slug = $nd_travel_settings['typology_slug'];
    $packagesgrid_image_size = $nd_travel_settings['thumbnail_size'];

    //default values
    if ($packages_width == '') { $packages_width = "nd_travel_width_100_percentage"; }
    if ($packages_layout == '') { $packages_layout = "layout-1"; }
    if ($packages_qnt == '') { $packages_qnt = -1; }
    if ($nd_travel_postgrid_order == '') { $nd_travel_postgrid_order = 'DESC'; }
    if ($nd_travel_postgrid_orderby == '') { $nd_travel_postgrid_orderby = 'date'; }
    if ($packagesgrid_image_size == '') { $packagesgrid_image_size = 'large'; }



    if ( $nd_travel_destination_id != '' ) {


      //---------------------------START----------------args with destination
      
      //prepare the destinations array
      $nd_travel_archive_form_destinations_array = array();
      $nd_travel_archive_form_destinations_array[0] = $nd_travel_destination_id;



      if ( $nd_travel_archive_form_destinations_array[0] == 1 ) {

        //display current destination ( i'm on single destination page )
        $nd_travel_destination_id = get_the_ID();
        $nd_travel_archive_form_destinations_array[0] = get_the_ID();

        if ( count(nd_travel_get_destinations_with_parent($nd_travel_destination_id)) != 0 ){

            //destination with children
            $nd_travel_destinations_query_i = 1;
            $nd_travel_children_destinations_array = nd_travel_get_destinations_with_parent($nd_travel_destination_id);

            foreach ($nd_travel_children_destinations_array as $nd_travel_children_destination_id) {
                
                $nd_travel_archive_form_destinations_array[$nd_travel_destinations_query_i] = $nd_travel_children_destination_id;
                $nd_travel_destinations_query_i = $nd_travel_destinations_query_i + 1;

            }

        }


      }else{

        if ( count(nd_travel_get_destinations_with_parent($nd_travel_destination_id)) != 0 ){

            //destination with children
            $nd_travel_destinations_query_i = 1;
            $nd_travel_children_destinations_array = nd_travel_get_destinations_with_parent($nd_travel_destination_id);

            foreach ($nd_travel_children_destinations_array as $nd_travel_children_destination_id) {
                
                $nd_travel_archive_form_destinations_array[$nd_travel_destinations_query_i] = $nd_travel_children_destination_id;
                $nd_travel_destinations_query_i = $nd_travel_destinations_query_i + 1;

            }

        } 

      }


      $args = array(
        'post_type' => 'nd_travel_cpt_1',
        'posts_per_page' => $packages_qnt,
        'order' => $nd_travel_postgrid_order,
        'orderby' => $nd_travel_postgrid_orderby,
        'p' => $packages_id,
        'meta_query' => array(
            array(
                'key'     => 'nd_travel_meta_box_destinations',
                'type' => 'numeric',
                'value'   => $nd_travel_archive_form_destinations_array,
            ),
        )
      );
      //---------------------------END----------------args with destination

    }elseif ( $nd_travel_typology_slug != '' ){


      //args with typology
      if ( $nd_travel_typology_slug == 1 ) { 
        $nd_travel_get_current_typology_id = get_the_ID();
        $nd_travel_get_current_typology_slug = get_post_field( 'post_name', $nd_travel_get_current_typology_id );  
      }else{
        $nd_travel_get_current_typology_slug = $nd_travel_typology_slug;
      }

      //args with typology
      $args = array(
        'post_type' => 'nd_travel_cpt_1',
        'posts_per_page' => $packages_qnt,
        'order' => $nd_travel_postgrid_order,
        'orderby' => $nd_travel_postgrid_orderby,
        'p' => $packages_id,
        'meta_query' => array(
            array(
                'key' => 'nd_travel_meta_box_typologies',
                'value'   => $nd_travel_get_current_typology_slug,
                'compare' => 'LIKE',
            ),  
        )
      );


    }else{ 

      //default args
      $args = array(
        'post_type' => 'nd_travel_cpt_1',
        'posts_per_page' => $packages_qnt,
        'order' => $nd_travel_postgrid_order,
        'orderby' => $nd_travel_postgrid_orderby,
        'p' => $packages_id,
      );

    }


    
    $the_query = new WP_Query( $args );

    //START LAYOUT
    $nd_travel_result .= '
    <div class="nd_travel_section nd_travel_masonry_content">';

      while ( $the_query->have_posts() ) : $the_query->the_post();

        //info
        $nd_travel_id = get_the_ID(); 
        $nd_travel_title = get_the_title();
        $nd_travel_excerpt = get_the_excerpt();
        $nd_travel_permalink = get_permalink( $nd_travel_id );

        //color
        $nd_travel_meta_box_color = get_post_meta( get_the_ID(), 'nd_travel_meta_box_color', true );
        if ( $nd_travel_meta_box_color == '' ){ $nd_travel_meta_box_color = '#1bbc9b'; }

        $nd_travel_meta_box_tab_gallery_content = get_post_meta( get_the_ID(), 'nd_travel_meta_box_tab_gallery_content', true );
        $nd_travel_meta_box_tab_map_content = get_post_meta( get_the_ID(), 'nd_travel_meta_box_tab_map_content', true );
        $nd_travel_meta_box_featured_image_replace = get_post_meta( get_the_ID(), 'nd_travel_meta_box_featured_image_replace', true );


        //get the layout selected
        $nd_travel_layout_selected = dirname( __FILE__ ).'/layout/'.$packages_layout.'.php';
        include realpath($nd_travel_layout_selected);

      endwhile;

    $nd_travel_result .= '
    </div>';
    //END LAYOUT

    wp_reset_postdata();

    $nd_travel_allowed_html = [
      'div'      => [  
        'id' => [],
        'class' => [],
        'style' => [],
      ],
      'a'      => [ 
        'class' => [],
        'href' => [],
        'style' => [],
      ],
      'img'      => [ 
        'alt' => [],
        'class' => [],
        'style' => [],
        'src' => [],
        'width' => [],
      ],
      'h3'      => [ 
        'class' => [],
      ],
      'span'      => [ 
        'class' => [],
        'style' => [],
      ],
      'h4'      => [ 
        'class' => [],
      ],
      'p'      => [
        'class' => [],
        'style' => [],
      ],
    ];

    //echo wp_kses( $nd_travel_result, $nd_travel_allowed_html );
    echo $nd_travel_result;

  }
  //END RENDER


}
//END ELEMENT POST GRID
