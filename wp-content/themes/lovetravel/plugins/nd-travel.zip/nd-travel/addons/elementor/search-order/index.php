<?php


//START ELEMENT POST GRID
class nd_travel_search_order_element extends \Elementor\Widget_Base {

	public function get_name() { return 'Search Order'; }
	public function get_title() { return __( 'Search Order', 'nd-travel' ); }
	public function get_icon() { return 'fa fa-search'; }
	public function get_categories() { return [ 'nd-travel' ]; }

	
	/*START CONTROLS*/
	protected function _register_controls() {

	
		/*Create Tab*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Main Options', 'nd-travel' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
	      'search_order_layout',
	      [
	        'label' => __( 'Layout', 'nd-travel' ),
	        'type' => \Elementor\Controls_Manager::SELECT,
	        'default' => 'layout-1',
	        'options' => [
	          'layout-1'  => __( 'Layout 1', 'nd-travel' ),
	        ],
	      ]
	    );

	    $this->end_controls_section();



		$this->start_controls_section(
			'price_name_order',
			[
				'label' => __( 'Price and Name Order', 'nd-travel' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'search_order_show_price',
			[
				'label' => esc_html__( 'Show Price Order', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'nd-travel' ),
				'label_off' => esc_html__( 'Hide', 'nd-travel' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'search_order_show_name',
			[
				'label' => esc_html__( 'Show Name Order', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'nd-travel' ),
				'label_off' => esc_html__( 'Hide', 'nd-travel' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'price_name_order_icon',
			[
				'label' => esc_html__( 'Icon', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-angle-down',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'price_name_order_align',
			[
				'label' => esc_html__( 'Alignment', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'nd-travel' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'nd-travel' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'nd-travel' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_search_filter_options' => 'float: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();




		$this->start_controls_section(
			'layout_order',
			[
				'label' => __( 'Layout Order', 'nd-travel' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'search_order_show_layout',
			[
				'label' => esc_html__( 'Show Layout Order', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'nd-travel' ),
				'label_off' => esc_html__( 'Hide', 'nd-travel' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'search_order_show_layout_icon_grid',
			[
				'label' => esc_html__( 'Icon Grid', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-th-large',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'search_order_show_layout_icon_list',
			[
				'label' => esc_html__( 'Icon List', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-th-list',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'layout_order_align',
			[
				'label' => esc_html__( 'Alignment', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'nd-travel' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'nd-travel' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'nd-travel' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_search_filter_layout' => 'float: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();




		$this->start_controls_section(
			'style_section_price_name',
			[
				'label' => esc_html__( 'Price and Name Order', 'nd-travel' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'style_section_price_name_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size p.nd_travel_cursor_pointer' => 'color: {{VALUE}}',
					'{{WRAPPER}} #nd_travel_vc_order_price p.nd_travel_cursor_pointer' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'nd-travel' ),
				'name' => 'style_section_price_name_typography',
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size p.nd_travel_cursor_pointer',
					'{{WRAPPER}} #nd_travel_vc_order_price p.nd_travel_cursor_pointer',
				],

			]
		);

		$this->add_control(
			'style_section_price_name_margin',
			[
				'label' => esc_html__( 'Padding', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} #nd_travel_vc_order_size' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'style_section_price_name_color_drop',
			[
				'label' => esc_html__( 'Text Color Dropdown', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size ul li a' => 'color: {{VALUE}}',
					'{{WRAPPER}} #nd_travel_vc_order_price ul li a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography Dropdown', 'nd-travel' ),
				'name' => 'style_section_price_name_typography_drop',
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size ul li a',
					'{{WRAPPER}} #nd_travel_vc_order_price ul li a',
				],
			]
		);


		$this->add_control(
			'style_section_price_name_color_bg',
			[
				'label' => esc_html__( 'Background Color Dropdown', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size ul li' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} #nd_travel_vc_order_price ul li' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'style_section_price_name_drop_padding',
			[
				'label' => esc_html__( 'Padding Item Dropdown', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} #nd_travel_vc_order_price ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->add_control(
			'style_section_price_name_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size i' => 'color: {{VALUE}}',
					'{{WRAPPER}} #nd_travel_vc_order_price i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'width',
			[
				'label' => esc_html__( 'Icon Width', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} #nd_travel_vc_order_size i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} #nd_travel_vc_order_price i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'style_section_layout',
			[
				'label' => esc_html__( 'Layout Order', 'nd-travel' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);





		$this->start_controls_tabs(
			'style_tabs_icon_grid_list'
		);

		$this->start_controls_tab(
			'style_normal_tab_icon_grid_list',
			[
				'label' => __( 'Normal', 'nd-travel' ),
			]
		);

		$this->add_control(
			'style_section_layout_icon_color',
			[
				'label' => esc_html__( 'Icons Color', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_search_filter_layout i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_active_tab_icon_grid_list',
			[
				'label' => __( 'Active', 'nd-travel' ),
			]
		);

		$this->add_control(
			'style_section_layout_icon_color_active',
			[
				'label' => esc_html__( 'Icons Color', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #nd_travel_search_filter_layout a.nd_travel_search_filter_layout_active i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();






		$this->add_control(
			'style_section_layout_icon_width',
			[
				'label' => esc_html__( 'Icons Width', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} #nd_travel_search_filter_layout i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'style_section_layout_icon_margin',
			[
				'label' => esc_html__( 'Icon Margin', 'nd-travel' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} a.nd_travel_search_filter_layout_grid' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; display:inline-block;',
					'{{WRAPPER}} a.nd_travel_search_filter_layout_list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; display:inline-block;',
				],
			]
		);

		$this->end_controls_section();



	   

	}
	//END CONTROLS


 
	/*START RENDER*/
	protected function render() {

		$nd_travel_result = '';

  		//get datas
  		$nd_travel_settings = $this->get_settings_for_display();
		$nd_travel_search_order_layout = $nd_travel_settings['search_order_layout'];

		$nd_travel_search_order_show_price = $nd_travel_settings['search_order_show_price'];
		$nd_travel_search_order_show_name = $nd_travel_settings['search_order_show_name'];
		$nd_travel_search_order_show_layout = $nd_travel_settings['search_order_show_layout'];


		$nd_travel_current_page_permalink = get_permalink(get_the_ID());
		if ( $nd_travel_current_page_permalink == nd_travel_search_page() ) {



			//price order
			$nd_travel_result_show_price = '';
			if ( $nd_travel_search_order_show_price == 'yes' ) {

				$nd_travel_result_show_price .= '

				<li id="nd_travel_vc_order_price" class="nd_travel_display_inline_block nd_travel_position_relative ">

					<p class="nd_travel_display_inline_block nd_travel_cursor_pointer">'.__('Price','nd-travel').'</p>
					<i class="'.$nd_travel_settings['price_name_order_icon']['value'].' nd_travel_margin_left_10"></i>

					<ul class="nd_travel_padding_top_20 nd_travel_z_index_99 nd_travel_width_160 nd_travel_list_style_none nd_travel_search_filter_options_child nd_travel_position_absolute nd_travel_left_0 nd_travel_top_30 nd_travel_display_none nd_travel_padding_0 nd_travel_margin_0 nd_travel_width_100_percentage">
						<li class="nd_travel_text_align_left "><a data-meta-key="nd_travel_meta_box_new_price" data-order="ASC" class="nd_travel_cursor_pointer">'.__('Lowest Price','nd-travel').'</a></li>
						<li class="nd_travel_text_align_left "><a data-meta-key="nd_travel_meta_box_new_price" data-order="DESC" class="nd_travel_cursor_pointer ">'.__('Highest Price','nd-travel').'</a></li>
					</ul>

				</li>

				';	

			}


			//name order
			$nd_travel_result_show_name = '';
			if ( $nd_travel_search_order_show_name == 'yes' ) {

				$nd_travel_result_show_name .= '

				<li id="nd_travel_vc_order_size" class="nd_travel_display_inline_block nd_travel_position_relative    ">

					<p class="nd_travel_display_inline_block nd_travel_cursor_pointer">'.__('Name','nd-travel').'</p> 
					<i class="'.$nd_travel_settings['price_name_order_icon']['value'].' nd_travel_margin_left_10"></i>

					<ul class="nd_travel_padding_top_20 nd_travel_z_index_99 nd_travel_width_160 nd_travel_list_style_none nd_travel_search_filter_options_child nd_travel_position_absolute nd_travel_left_0 nd_travel_top_30 nd_travel_display_none nd_travel_padding_0 nd_travel_margin_0 nd_travel_width_100_percentage">
						<li class="nd_travel_text_align_left "><a data-meta-key="nd_travel_name" data-order="DESC" class="nd_travel_cursor_pointer">'.__('Desc','nd-travel').'</a></li>
						<li class="nd_travel_text_align_left "><a data-meta-key="nd_travel_name" data-order="ASC" class="nd_travel_cursor_pointer">'.__('Asc','nd-travel').'</a></li>
					</ul>

				</li>

				';	

			}




			//name order
			$nd_travel_result_show_layout = '';
			if ( $nd_travel_search_order_show_layout == 'yes' ) {

				$nd_travel_result_show_layout .= '

				<div id="nd_travel_search_filter_layout" class="nd_travel_display_none_all_iphone nd_travel_display_inline_block">

					<a data-layout="1" class="nd_travel_search_filter_layout_grid nd_travel_cursor_pointer nd_travel_search_filter_layout_active">
						<i class="'.$nd_travel_settings['search_order_show_layout_icon_grid']['value'].'"></i>
					</a>

					<a data-layout="2" class="nd_travel_search_filter_layout_list nd_travel_cursor_pointer">
						<i class="'.$nd_travel_settings['search_order_show_layout_icon_list']['value'].'"></i>
					</a>

				</div>

				';	

			}







		    $nd_travel_result .= '

			<script type="text/javascript">
			  //<![CDATA[
			  
			  jQuery(document).ready(function() {

			    
			    jQuery(function ($) {
			      
			      $( "#nd_travel_search_filter_options a" ).on("click",function() {

			        $( "#nd_travel_search_filter_options a" ).removeClass( "nd_travel_search_filter_options_active" );
			        $(this).addClass( "nd_travel_search_filter_options_active");

			        nd_travel_sorting(1);
			      
			      });

			      $( "#nd_travel_search_filter_layout a" ).on("click",function() {

			        $( "#nd_travel_search_filter_layout a" ).removeClass( "nd_travel_search_filter_layout_active" );
			        $(this).addClass( "nd_travel_search_filter_layout_active");

			        nd_travel_sorting();

			      });

			      
			      $("#nd_travel_search_filter_options li").on("click",function() {
			        $("#nd_travel_search_filter_options li").removeClass( "nd_travel_search_filter_options_active_parent" );
			        $(this).addClass( "nd_travel_search_filter_options_active_parent");
			      });

			    });
			    

			  });

			  //]]>
			</script>

		    

		    <style>
		    #nd_travel_search_filter_options li:hover .nd_travel_search_filter_options_child { display: block; }
		    #nd_travel_search_filter_options li p { border-bottom-width:0px !important; }

		    a.nd_travel_search_filter_layout_grid:hover,
		    a.nd_travel_search_filter_layout_list:hover { opacity:0.7; }

		    #nd_travel_vc_order_price ul li a,
		    #nd_travel_vc_order_size ul li a { display: inline-block; line-height: 1em; }

		    </style>



		  	<div id="nd_travel_vc_order" class="nd_travel_section">

		  		<div id="nd_travel_search_results_order_options" class="nd_travel_section nd_travel_box_sizing_border_box  nd_travel_text_align_center">

		        	<div class="nd_travel_section nd_travel_position_relative nd_travel_line_height_0">

						<ul id="nd_travel_search_filter_options" class="nd_travel_list_style_none nd_travel_display_inline_block nd_travel_padding_0 nd_travel_margin_0">
						  
							'.$nd_travel_result_show_price.'
							'.$nd_travel_result_show_name.'

						</ul> 

						'.$nd_travel_result_show_layout.'

		    		</div>
				</div>
			</div>';


		}


		echo $nd_travel_result;


	}
	//END RENDER


}
//END ELEMENT POST GRID
