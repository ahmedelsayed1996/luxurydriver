<?php


//START ELEMENT POST GRID
class nd_travel_search_element extends \Elementor\Widget_Base {

  public function get_name() { return 'Search'; }
  public function get_title() { return __( 'Search', 'nd-travel' ); }
  public function get_icon() { return 'fa fa-hands-helping'; }
  public function get_categories() { return [ 'nd-travel' ]; }

  /*START CONTROLS*/
  protected function _register_controls() {

    /*Create Tab*/
    $this->start_controls_section(
      'content_section',
      [
        'label' => __( 'Main Options', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->add_control(
      'search_layout',
      [
        'label' => __( 'Layout', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'layout-1',
        'options' => [
          'layout-1'  => __( 'Layout 1', 'nd-travel' ),
        ],
      ]
    );


    $this->add_control(
      'search_columns',
      [
        'label' => __( 'Columns', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'nd_elements_width_25_percentage',
        'options' => [
          'nd_elements_width_100_percentage'  => __( '1 Column', 'nd-travel' ),
          'nd_elements_width_50_percentage' => __( '2 Columns', 'nd-travel' ),
          'nd_elements_width_33_percentage'  => __( '3 Columns', 'nd-travel' ),
          'nd_elements_width_25_percentage' => __( '4 Columns', 'nd-travel' ),
          'nd_elements_width_20_percentage' => __( '5 Columns', 'nd-travel' ),
        ],
      ]
    );

    $this->end_controls_section();



    
    $this->start_controls_section(
      'content_section_keyword',
      [
        'label' => __( 'Keyword', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


    $this->add_control(
      'search_keyword_show',
      [
        'label' => esc_html__( 'Keyword', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Show', 'nd-travel' ),
        'label_off' => esc_html__( 'Hide', 'nd-travel' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'search_keyword_title',
      [
        'label' => esc_html__( 'Label', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'Keyword', 'nd-travel' ),
        'placeholder' => esc_html__( 'Type your title here', 'nd-travel' ),
        'condition' => [
          'search_keyword_show' => [ 'yes'],
        ],
      ]
    );


    $this->add_control(
      'search_keyword_icon',
      [
        'label' => esc_html__( 'Icon', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'condition' => [
          'search_keyword_show' => [ 'yes'],
        ],
      ]
    );

    $this->end_controls_section();








    $this->start_controls_section(
      'content_section_destinations',
      [
        'label' => __( 'Destinations', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


    $this->add_control(
      'search_destination_show',
      [
        'label' => esc_html__( 'Destinations', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Show', 'nd-travel' ),
        'label_off' => esc_html__( 'Hide', 'nd-travel' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'search_destination_title',
      [
        'label' => esc_html__( 'Label', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'Destinations', 'nd-travel' ),
        'placeholder' => esc_html__( 'Type your title here', 'nd-travel' ),
        'condition' => [
          'search_destination_show' => [ 'yes'],
        ],
      ]
    );


    $this->add_control(
      'search_destination_icon',
      [
        'label' => esc_html__( 'Icon', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'condition' => [
          'search_destination_show' => [ 'yes'],
        ],
      ]
    );

    $this->end_controls_section();





    $this->start_controls_section(
      'content_section_typologies',
      [
        'label' => __( 'Typologies', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


    $this->add_control(
      'search_typologies_show',
      [
        'label' => esc_html__( 'Typologies', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Show', 'nd-travel' ),
        'label_off' => esc_html__( 'Hide', 'nd-travel' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'search_typologies_title',
      [
        'label' => esc_html__( 'Label', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'Typologies', 'nd-travel' ),
        'placeholder' => esc_html__( 'Type your title here', 'nd-travel' ),
        'condition' => [
          'search_typologies_show' => [ 'yes'],
        ],
      ]
    );


    $this->add_control(
      'search_typologies_icon',
      [
        'label' => esc_html__( 'Icon', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'condition' => [
          'search_typologies_show' => [ 'yes'],
        ],
      ]
    );

    $this->end_controls_section();




    $this->start_controls_section(
      'content_section_durations',
      [
        'label' => __( 'Durations', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


    $this->add_control(
      'search_durations_show',
      [
        'label' => esc_html__( 'Durations', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Show', 'nd-travel' ),
        'label_off' => esc_html__( 'Hide', 'nd-travel' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'search_durations_title',
      [
        'label' => esc_html__( 'Label', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'Durations', 'nd-travel' ),
        'placeholder' => esc_html__( 'Type your title here', 'nd-travel' ),
        'condition' => [
          'search_durations_show' => [ 'yes'],
        ],
      ]
    );


    $this->add_control(
      'search_durations_icon',
      [
        'label' => esc_html__( 'Icon', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'condition' => [
          'search_durations_show' => [ 'yes'],
        ],
      ]
    );

    $this->end_controls_section();





    $this->start_controls_section(
      'content_section_difficulties',
      [
        'label' => __( 'Difficulties', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


    $this->add_control(
      'search_difficulties_show',
      [
        'label' => esc_html__( 'Difficulties', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Show', 'nd-travel' ),
        'label_off' => esc_html__( 'Hide', 'nd-travel' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'search_difficulties_title',
      [
        'label' => esc_html__( 'Label', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'Difficulties', 'nd-travel' ),
        'placeholder' => esc_html__( 'Type your title here', 'nd-travel' ),
        'condition' => [
          'search_difficulties_show' => [ 'yes'],
        ],
      ]
    );


    $this->add_control(
      'search_difficulties_icon',
      [
        'label' => esc_html__( 'Icon', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'condition' => [
          'search_difficulties_show' => [ 'yes'],
        ],
      ]
    );

    $this->end_controls_section();




    $this->start_controls_section(
      'content_section_minages',
      [
        'label' => __( 'Min Ages', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


    $this->add_control(
      'search_minages_show',
      [
        'label' => esc_html__( 'Min Ages', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Show', 'nd-travel' ),
        'label_off' => esc_html__( 'Hide', 'nd-travel' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'search_minages_title',
      [
        'label' => esc_html__( 'Label', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( 'Min Ages', 'nd-travel' ),
        'placeholder' => esc_html__( 'Type your title here', 'nd-travel' ),
        'condition' => [
          'search_minages_show' => [ 'yes'],
        ],
      ]
    );


    $this->add_control(
      'search_minages_icon',
      [
        'label' => esc_html__( 'Icon', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'condition' => [
          'search_minages_show' => [ 'yes'],
        ],
      ]
    );

    $this->end_controls_section();





    $this->start_controls_section(
      'style_content',
      [
        'label' => __( 'Content', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );

    $this->add_control(
      'style_content_bg_color',
      [
        'label' => esc_html__( 'Background Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_elementor_search_component' => 'background-color: {{VALUE}}',
        ],
      ]
    );

    $this->add_responsive_control(
      'style_content_padding',
      [
        'label' => esc_html__( 'Padding', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_elementor_search_component' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_control(
      'style_content_margin',
      [
        'label' => esc_html__( 'Margin', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_elementor_search_component' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Border::get_type(),
      [
        'name' => 'style_content_border',
        'selector' => '{{WRAPPER}} .nd_travel_elementor_search_component',
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Box_Shadow::get_type(),
      [
        'name' => 'style_content_box_shadow',
        'selector' => '{{WRAPPER}} .nd_travel_elementor_search_component',
      ]
    );

    $this->add_control(
      'style_content_border_radius',
      [
        'label' => esc_html__( 'Border Radius', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 100,
            'step' => 1,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_elementor_search_component' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
      ]
    );

    $this->end_controls_section();



    $this->start_controls_section(
      'style_label',
      [
        'label' => __( 'Label', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );


    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'style_label_text_typography',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_label',
      ]
    );


     $this->add_control(
      'style_label_text_color',
      [
        'label' => esc_html__( 'Text Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_label' => 'color: {{VALUE}}',
        ],
      ]
    );


    $this->end_controls_section();



     $this->start_controls_section(
      'style_field',
      [
        'label' => __( 'Fields', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );


     $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'style_field_text_typography',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_field',
      ]
    );


     $this->add_control(
      'style_field_text_color',
      [
        'label' => esc_html__( 'Text Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_field' => 'color: {{VALUE}}',
        ],
      ]
    );

     $this->add_control(
      'style_field_bg_color',
      [
        'label' => esc_html__( 'Background Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_field' => 'background-color: {{VALUE}}',
        ],
      ]
    );


     $this->add_control(
      'style_field_padding',
      [
        'label' => esc_html__( 'Padding', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_field' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Border::get_type(),
      [
        'name' => 'style_field_border',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_field',
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Box_Shadow::get_type(),
      [
        'name' => 'style_field_box_shadow',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_field',
      ]
    );

    $this->add_control(
      'style_field_border_radius',
      [
        'label' => esc_html__( 'Border Radius', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 100,
            'step' => 1,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_field' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
      ]
    );


     


     $this->end_controls_section();






     $this->start_controls_section(
      'style_submit',
      [
        'label' => __( 'Submit', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );


     $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'style_submit_text_typography',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_submit',
      ]
    );


     $this->add_control(
      'style_submit_text_color',
      [
        'label' => esc_html__( 'Text Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_submit' => 'color: {{VALUE}}',
        ],
      ]
    );

     $this->add_control(
      'style_submit_bg_color',
      [
        'label' => esc_html__( 'Background Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_submit' => 'background-color: {{VALUE}}',
        ],
      ]
    );


     $this->add_control(
      'style_submit_padding',
      [
        'label' => esc_html__( 'Padding', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Border::get_type(),
      [
        'name' => 'style_submit_border',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_submit',
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Box_Shadow::get_type(),
      [
        'name' => 'style_submit_box_shadow',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_submit',
      ]
    );

    $this->add_control(
      'style_submit_border_radius',
      [
        'label' => esc_html__( 'Border Radius', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 100,
            'step' => 1,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_submit' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
      ]
    );


     


     $this->end_controls_section();







     $this->start_controls_section(
      'style_column',
      [
        'label' => __( 'Columns', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );


     $this->add_control(
      'style_column_padding',
      [
        'label' => esc_html__( 'Padding', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_column' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_group_control(
      \Elementor\Group_Control_Border::get_type(),
      [
        'name' => 'style_column_border',
        'selector' => '{{WRAPPER}} .nd_travel_search_components_column',
      ]
    );

  
     $this->end_controls_section();






     $this->start_controls_section(
      'style_icon',
      [
        'label' => __( 'Icons', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );

     $this->add_control(
      'style_icon_text_color',
      [
        'label' => esc_html__( 'Color', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_icon' => 'color: {{VALUE}}',
        ],
      ]
    );


     $this->add_control(
      'style_icon_width',
      [
        'label' => esc_html__( 'Width', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 100,
            'step' => 1,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_icon' => 'width: {{SIZE}}{{UNIT}}; font-size: {{SIZE}}{{UNIT}};',
        ],
      ]
    );


     $this->add_control(
      'style_icon_padding',
      [
        'label' => esc_html__( 'Padding', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
        'selectors' => [
          '{{WRAPPER}} .nd_travel_search_components_icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );
     

  
     $this->end_controls_section();






  }
  //END CONTROLS


 
  /*START RENDER*/
  protected function render() {

    $nd_travel_result = '';

    //get datas
    $nd_travel_settings = $this->get_settings_for_display();
    $search_layout = $nd_travel_settings['search_layout'];
    if ($search_layout == '') { $search_layout = "layout-1"; }
    $nd_travel_setting_search_columns = $nd_travel_settings['search_columns'];
    
    $nd_travel_setting_search_keyword_show = $nd_travel_settings['search_keyword_show'];
    $nd_travel_setting_search_keyword_title = $nd_travel_settings['search_keyword_title'];
    $nd_travel_setting_search_keyword_icon = $nd_travel_settings['search_keyword_icon'];
    
    $nd_travel_setting_search_destination_show = $nd_travel_settings['search_destination_show'];
    $nd_travel_setting_search_destination_title = $nd_travel_settings['search_destination_title'];
    $nd_travel_setting_search_destination_icon = $nd_travel_settings['search_destination_icon'];
  
    $nd_travel_setting_search_typologies_show = $nd_travel_settings['search_typologies_show'];
    $nd_travel_setting_search_typologies_title = $nd_travel_settings['search_typologies_title'];
    $nd_travel_setting_search_typologies_icon = $nd_travel_settings['search_typologies_icon'];    
    
    $nd_travel_setting_search_durations_show = $nd_travel_settings['search_durations_show'];
    $nd_travel_setting_search_durations_title = $nd_travel_settings['search_durations_title'];
    $nd_travel_setting_search_durations_icon = $nd_travel_settings['search_durations_icon'];
    
    $nd_travel_setting_search_difficulties_show = $nd_travel_settings['search_difficulties_show'];
    $nd_travel_setting_search_difficulties_title = $nd_travel_settings['search_difficulties_title'];
    $nd_travel_setting_search_difficulties_icon = $nd_travel_settings['search_difficulties_icon'];
    
    $nd_travel_setting_search_minages_show = $nd_travel_settings['search_minages_show'];
    $nd_travel_setting_search_minages_title = $nd_travel_settings['search_minages_title'];
    $nd_travel_setting_search_minages_icon = $nd_travel_settings['search_minages_icon'];
    

    //generate id
    $nd_travel_elementor_search_component_id = rand(100000, 999999);

    //get the layout selected
    $nd_travel_layout_selected = dirname( __FILE__ ).'/layout/'.$search_layout.'.php';
    include realpath($nd_travel_layout_selected);

    //echo result
    $nd_travel_allowed_html = [
      'div'      => [  
        'id' => [],
        'class' => [],
        'style' => [],
      ],
      'a'      => [ 
        'class' => [],
        'href' => [],
        'style' => [],
      ],
      'img'      => [ 
        'alt' => [],
        'class' => [],
        'src' => [],
        'width' => [],
      ],
      'h3'      => [ 
        'class' => [],
      ],
      'span'      => [ 
        'class' => [],
        'style' => [],
      ],
      'h4'      => [ 
        'class' => [],
      ],
      'i'      => [ 
        'class' => [],
      ],
      'p'      => [
        'class' => [],
      ],
      'label'      => [
        'class' => [],
      ],
      'select'      => [
        'class' => [],
        'name' => [],
      ],
      'option'      => [
        'value' => [],
        'class' => [],
      ],
      'form'      => [
        'id' => [],
        'class' => [],
        'action' => [],
        'method' => [],
      ],
      'input'      => [
        'id' => [],
        'class' => [],
        'type' => [],
        'value' => [],
        'name' => [],
        'placeholder' => [],
      ],
    ];

    echo wp_kses( $nd_travel_result, $nd_travel_allowed_html );

  }
  //END RENDER



}
//END ELEMENT POST GRID




function nd_travel_elementor_build_select($nd_travel_tax,$nd_travel_i,$nd_travel_width,$nd_travel_show,$nd_travel_label,$nd_travel_icon){ 

    //declare
    $nd_travel_select = '';

    //get all terms
    $nd_travel_terms = get_terms($nd_travel_tax);

    //get tax
    $nd_travel_the_tax = get_taxonomy($nd_travel_tax);

    //get name
    $nd_travel_tax_name = $nd_travel_the_tax->labels->name;

    //label
    $nd_travel_result_label = '';
    if ( $nd_travel_label != '' ) { $nd_travel_result_label = '<label class="nd_travel_search_components_label">'.$nd_travel_label.'</label>'; }

    //icon
    $nd_travel_result_icon = '';
    if ( !empty($nd_travel_icon) ) {

      if ( is_array($nd_travel_icon['value']) ) {
        $nd_travel_result_icon .= '<img class="nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon" src="'.$nd_travel_icon['value']['url'].'">';
      }else{
        $nd_travel_result_icon .= '<i class=" nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon '.$nd_travel_icon['value'].'"></i>';    
      }
    }else{
      $nd_travel_result_icon .= '';
    }


    if ( $nd_travel_show == 'yes' ) {

      //START LAYOUT 1
      $nd_travel_select .= '
      <div id="nd_travel_search_components_tax_'.$nd_travel_i.'" class="nd_travel_float_left nd_travel_position_relative nd_travel_width_100_percentage_responsive nd_travel_box_sizing_border_box nd_travel_search_components_column '.$nd_travel_width.' ">

        '.$nd_travel_result_icon.'

        '.$nd_travel_result_label.'
        
        <select class="nd_travel_section nd_travel_search_components_field" name="'.$nd_travel_tax.'">';

      //default value
      $nd_travel_select .= '<option value="">'.__('All','nd-travel').' '. $nd_travel_tax_name .'</option>';

      //built options
      foreach ($nd_travel_terms as $nd_travel_term) {
        $nd_travel_select .= '<option value="' . $nd_travel_term->term_id . '">' . $nd_travel_term->name . '</option>';  
      }

      $nd_travel_select .= '</select></div>';
      //END LAYOUT 1

    }

    return $nd_travel_select;

  }
