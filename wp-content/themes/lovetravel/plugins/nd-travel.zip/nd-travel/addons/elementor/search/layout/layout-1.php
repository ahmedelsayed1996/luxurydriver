<?php


/* 1 - keyword */
$nd_travel_result_keyword = '';

$nd_travel_result_keyword_label = '';
if ( $nd_travel_setting_search_keyword_title != '' ) { $nd_travel_result_keyword_label = '<label class="nd_travel_search_components_label">'.$nd_travel_setting_search_keyword_title.'</label>'; }

//icon
$nd_travel_result_keyword_icon = '';
if ( !empty($nd_travel_setting_search_keyword_icon) ) {

	if ( is_array($nd_travel_setting_search_keyword_icon['value']) ) {
		$nd_travel_result_keyword_icon .= '<img class="nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon" src="'.$nd_travel_setting_search_keyword_icon['value']['url'].'">';
	}else{
		$nd_travel_result_keyword_icon .= '<i class=" nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon '.$nd_travel_setting_search_keyword_icon['value'].'"></i>';		
	}
}else{
	$nd_travel_result_keyword_icon .= '';
}


$nd_travel_result_keyword .= '
<div id="nd_travel_search_components_keyword" class=" nd_travel_position_relative nd_travel_margin_bottom_20_responsive nd_travel_float_left nd_travel_width_100_percentage_responsive nd_travel_box_sizing_border_box nd_travel_search_components_column '.$nd_travel_setting_search_columns.' ">
    
  '.$nd_travel_result_keyword_icon.'  

  '.$nd_travel_result_keyword_label .'
  
  <input id="nd_travel_vc_search_l1_keyword" name="nd_travel_archive_form_keyword" placeholder="'.__('Insert keyword','nd-travel').'" value="" class="nd_travel_section nd_travel_search_components_field " type="text">
</div>
';
/* END keyword */


/* 2 - destinations */
$nd_travel_result_destinations = '';

$nd_travel_result_destinations_label = '';
if ( $nd_travel_setting_search_destination_title != '' ) { $nd_travel_result_destinations_label = '<label class="nd_travel_search_components_label">'.$nd_travel_setting_search_destination_title.'</label>'; }


//icon
$nd_travel_result_destinations_icon = '';
if ( !empty($nd_travel_setting_search_destination_icon) ) {

	if ( is_array($nd_travel_setting_search_destination_icon['value']) ) {
		$nd_travel_result_destinations_icon .= '<img class="nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon" src="'.$nd_travel_setting_search_destination_icon['value']['url'].'">';
	}else{
		$nd_travel_result_destinations_icon .= '<i class=" nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon '.$nd_travel_setting_search_destination_icon['value'].'"></i>';		
	}
}else{
	$nd_travel_result_destinations_icon .= '';
}


$nd_travel_destinations_args = array( 
  'posts_per_page' => -1, 
  'post_type'=> 'nd_travel_cpt_3'
);
$nd_travel_destinations_query = new WP_Query( $nd_travel_destinations_args );
$nd_travel_destinations_query_i = 0;

$nd_travel_result_destinations .= '
<div id="nd_travel_search_components_destinations" class=" nd_travel_position_relative nd_travel_margin_bottom_20_responsive nd_travel_float_left nd_travel_width_100_percentage_responsive nd_travel_box_sizing_border_box nd_travel_search_components_column '.$nd_travel_setting_search_columns.' ">

  '.$nd_travel_result_destinations_icon.'
  '.$nd_travel_result_destinations_label.'
  
  <select class="nd_travel_section nd_travel_search_components_field" name="nd_travel_archive_form_destinations">';

    while ( $nd_travel_destinations_query->have_posts() ) : $nd_travel_destinations_query->the_post();

      $nd_travel_destination_id = get_the_ID();

      if ( $nd_travel_destinations_query_i == 0 ) { $nd_travel_result_destinations .= '<option value="0">'.__('All Destinations','nd-travel').'</option>'; }

      //not insert if parent is setted
      $nd_travel_meta_box_parent_destination = get_post_meta( get_the_ID(), 'nd_travel_meta_box_parent_destination', true );
      if ( $nd_travel_meta_box_parent_destination != 0 ) {
        $nd_travel_result_destinations .= '';
      }else{


        $nd_travel_result_destinations .= '<option value="'.$nd_travel_destination_id.'">'.get_the_title().'</option>';

        //check if the destination selected has some children destinations
        if ( count(nd_travel_get_destinations_with_parent($nd_travel_destination_id)) != 0 ){

          $nd_travel_children_destinations_array = nd_travel_get_destinations_with_parent($nd_travel_destination_id);

          foreach ($nd_travel_children_destinations_array as $nd_travel_children_destination_id) {
              
            //get parent id of children dest
            $nd_travel_parent_id_of_children_dest = get_post_meta( $nd_travel_children_destination_id, 'nd_travel_meta_box_parent_destination', true );

            if ( $nd_travel_parent_id_of_children_dest == $nd_travel_destination_id ) {
              $nd_travel_result_destinations .= '<option value="'.$nd_travel_children_destination_id.'">&nbsp;&nbsp;- '.get_the_title($nd_travel_children_destination_id).'</option>';  
            }

          }

        }


      }

      $nd_travel_destinations_query_i = $nd_travel_destinations_query_i + 1;

    endwhile; 

    wp_reset_postdata();

  $nd_travel_result_destinations .= '
  </select>
</div>
';
/* END destinations */



/* 3 - typlogies */
$nd_travel_result_typlogies = '';

$nd_travel_result_typlogies_label = '';
if ( $nd_travel_setting_search_typologies_title != '' ) { $nd_travel_result_typlogies_label = '<label class="nd_travel_search_components_label">'.$nd_travel_setting_search_typologies_title.'</label>'; }


//icon
$nd_travel_result_typlogies_icon = '';
if ( !empty($nd_travel_setting_search_typologies_icon) ) {

	if ( is_array($nd_travel_setting_search_typologies_icon['value']) ) {
		$nd_travel_result_typlogies_icon .= '<img class="nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon" src="'.$nd_travel_setting_search_typologies_icon['value']['url'].'">';
	}else{
		$nd_travel_result_typlogies_icon .= '<i class=" nd_travel_position_absolute nd_travel_top_0 nd_travel_left_0 nd_travel_search_components_icon '.$nd_travel_setting_search_typologies_icon['value'].'"></i>';		
	}
}else{
	$nd_travel_result_typlogies_icon .= '';
}


$nd_travel_typlogies_args = array( 
  'posts_per_page' => -1, 
  'post_type'=> 'nd_travel_cpt_2'
);
$nd_travel_typlogies_query = new WP_Query( $nd_travel_typlogies_args );
$nd_travel_typlogies_query_i = 0;

$nd_travel_result_typlogies .= '
<div id="nd_travel_search_components_typlogies" class=" nd_travel_position_relative nd_travel_margin_bottom_20_responsive nd_travel_float_left nd_travel_width_100_percentage_responsive nd_travel_box_sizing_border_box nd_travel_search_components_column '.$nd_travel_setting_search_columns.' ">

  '.$nd_travel_result_typlogies_icon.'
  '.$nd_travel_result_typlogies_label.'

  <select class="nd_travel_section nd_travel_search_components_field" name="nd_travel_typology_slug">';

  while ( $nd_travel_typlogies_query->have_posts() ) : $nd_travel_typlogies_query->the_post();

    if ( $nd_travel_typlogies_query_i == 0 ) { 
      $nd_travel_result_typlogies .= '<option value="">'.__('All Typologies','nd-travel').'</option>'; 
    }
    
    $nd_travel_result_typlogies .= '<option value="'.get_the_ID().'">'.get_the_title().'</option>';
    $nd_travel_typlogies_query_i = $nd_travel_typlogies_query_i + 1;

  endwhile; 

  wp_reset_postdata();
  
  $nd_travel_result_typlogies .= ' 
  </select>

</div>';
/* END typlogies */



/* 4 - taxonomies */
$nd_travel_result_taxonomies = '';
$nd_travel_result_taxonomies .= '';
$nd_travel_taxonomies = get_object_taxonomies('nd_travel_cpt_1');

//call the functions for each tax
$nd_travel_i = 0;
foreach($nd_travel_taxonomies as $nd_travel_tax){

  if ( $nd_travel_tax == 'nd_travel_cpt_1_tax_1' ) { 
    $nd_travel_setting_show = $nd_travel_setting_search_durations_show; 
    $nd_travel_setting_label = $nd_travel_setting_search_durations_title;
    $nd_travel_setting_icon = $nd_travel_setting_search_durations_icon;
  }
  if ( $nd_travel_tax == 'nd_travel_cpt_1_tax_2' ) { 
    $nd_travel_setting_show = $nd_travel_setting_search_difficulties_show; 
    $nd_travel_setting_label = $nd_travel_setting_search_difficulties_title;
    $nd_travel_setting_icon = $nd_travel_setting_search_difficulties_icon;
  }
  if ( $nd_travel_tax == 'nd_travel_cpt_1_tax_3' ) { 
    $nd_travel_setting_show = $nd_travel_setting_search_minages_show; 
    $nd_travel_setting_label = $nd_travel_setting_search_minages_title;
    $nd_travel_setting_icon = $nd_travel_setting_search_minages_icon;
  }

  $nd_travel_result_taxonomies .= nd_travel_elementor_build_select($nd_travel_tax,$nd_travel_i,$nd_travel_setting_search_columns,$nd_travel_setting_show,$nd_travel_setting_label,$nd_travel_setting_icon);
  $nd_travel_i = $nd_travel_i + 1;

}
/* END taxonomies */



/* SUBMIT */
$nd_travel_result_submit = '';
$nd_travel_result_submit .= '
<div id="nd_travel_search_components_submit" class="nd_travel_float_left nd_travel_width_100_percentage_responsive nd_travel_box_sizing_border_box  '.$nd_travel_setting_search_columns.' ">
  <input class="nd_travel_width_100_percentage nd_travel_search_components_submit nd_travel_cursor_pointer" type="submit" value="'.__('SEARCH','nd-travel').'">
</div>
';

/* END SUBMIT */






/*START search*/
$nd_travel_result .= '

  <div id="nd_travel_elementor_search_component_id_'.$nd_travel_elementor_search_component_id.'" class="nd_travel_float_left nd_travel_width_100_percentage nd_travel_elementor_search_component nd_travel_box_sizing_border_box">
    
    <form action="'.nd_travel_search_page().'" method="get">';

      if ( $nd_travel_setting_search_keyword_show == 'yes' ) { $nd_travel_result .= $nd_travel_result_keyword; }
      if ( $nd_travel_setting_search_destination_show == 'yes' ) { $nd_travel_result .= $nd_travel_result_destinations; }
      if ( $nd_travel_setting_search_typologies_show == 'yes' ) { $nd_travel_result .= $nd_travel_result_typlogies; }

      $nd_travel_result .= '

      '.$nd_travel_result_taxonomies.'

      '.$nd_travel_result_submit.'

    </form>

  </div>

';
/*END search*/ 