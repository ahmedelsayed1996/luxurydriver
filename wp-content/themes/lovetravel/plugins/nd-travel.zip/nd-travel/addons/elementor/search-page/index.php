<?php


//START
class nd_travel_search_page_element extends \Elementor\Widget_Base {

  public function get_name() { return 'Search Page'; }
  public function get_title() { return __( 'Search Page', 'nd-travel' ); }
  public function get_icon() { return 'fa fa-search'; }
  public function get_categories() { return [ 'nd-travel' ]; }

  /*START CONTROLS*/
  protected function _register_controls() {

    /*Create Tab*/
    $this->start_controls_section(
      'content_section',
      [
        'label' => __( 'Main Options', 'nd-travel' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->add_control(
      'search_page_layout',
      [
        'label' => __( 'Layout', 'nd-travel' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'layout-1',
        'options' => [
          'layout-1'  => __( 'Default Layout', 'nd-travel' ),
        ],
      ]
    );

    $this->end_controls_section();


  }
  //END CONTROLS


 
  /*START RENDER*/
  protected function render() {

    $nd_travel_result = '';

    //get datas
    $nd_travel_settings = $this->get_settings_for_display();
    $search_layout = $nd_travel_settings['search_page_layout'];

    echo do_shortcode( '[nd_travel_search_results layout="layout-3"]' );

  }
  //END RENDER





}
//END


