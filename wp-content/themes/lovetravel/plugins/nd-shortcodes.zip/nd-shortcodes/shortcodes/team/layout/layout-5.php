<?php

  
$str .= '

  <!--START team-->
  <div class=" nd_options_team_component_l5 nd_options_section nd_options_box_sizing_border_box '.$nd_options_class.' ">    
    <div class="nd_options_section nd_options_position_relative">

      <img alt="" class="nd_options_section" src="'.$nd_options_image_src[0].'">

      <div class="nd_options_bg_greydark_alpha_gradient_3 nd_options_position_absolute nd_options_left_0 nd_options_height_100_percentage nd_options_width_100_percentage nd_options_box_sizing_border_box">
        <div class="nd_options_position_absolute nd_options_bottom_30 nd_options_width_100_percentage nd_options_padding_botttom_0 nd_options_padding_50 nd_options_box_sizing_border_box nd_options_text_align_center">
          <h3 class="nd_options_color_white">'.$nd_options_title.'</h3>
          <div class="nd_options_section nd_options_height_10"></div>
          <h6 class="nd_options_color_white"><strong>'.$nd_options_role.'</strong></h6>
        </div>
      </div>

    </div>
  </div>
  <!--END team-->
';