<?php

  
$str .= '


  <!--START team-->
  <div class="nd_options_section '.$nd_options_class.'">
                                        
    <!--image-->
    <div class="nd_options_section">
        
        <img alt="" class="nd_options_section" src="'.$nd_options_image_src[0].'">

    </div>
    <!--image-->


    <div class="nd_options_section nd_options_padding_20 nd_options_box_sizing_border_box">
    
        <h2 class="nd_options_margin_0_important"><strong>'.$nd_options_title.'</strong></h2>
        <div class="nd_options_section nd_options_height_10"></div> 
        <h6 class="nd_options_text_transform_uppercase nd_options_margin_0_important">'.$nd_options_role.'</h6>
        <div class="nd_options_section nd_options_height_20"></div> 
        <p class="nd_options_margin_0_important">'.$nd_options_description.'</p>
        <div class="nd_options_section nd_options_height_20"></div> 
        <a rel="'.$nd_options_link_rel.'" target="'.$nd_options_link_target.'" style="background-color:'.$nd_options_color.';" class="nd_options_margin_0_important nd_options_display_inline_block nd_options_color_white nd_options_first_font nd_options_padding_8 nd_options_border_radius_3 nd_options_font_size_13" href="'.$nd_options_link_url.'">'.$nd_options_link_title.'</a>

    </div>

  </div>
  <!--END team-->


   ';