<?php

  
$str .= '

    <div class="nd_options_section '.$nd_options_class.'">    
        <h1 style="color:'.$nd_options_title_color.';" class="nd_options_font_size_40"><strong><span style="color:'.$nd_options_number_color.';">'.$nd_options_number.'.</span> '.$nd_options_title.'</strong></h1>
        <div class="nd_options_section nd_options_height_20"></div>
        <p style="color:'.$nd_options_description_color.';">'.$nd_options_description.'</p>
    </div>

  ';
