<?php

  
$str .= '

  <!--START FOCUS NUMBER-->
  <div class=" '.$nd_options_class.' nd_options_section nd_options_box_sizing_border_box nd_options_text_align_center">
    
    <div class="nd_options_section nd_options_height_15"></div>
    <div class="nd_options_section nd_options_height_1 nd_options_border_bottom_1_solid_grey">
      <div style="border: 7px solid '.$nd_options_bg_color.' " class="nd_options_bg_white nd_options_width_30 nd_options_height_30 nd_options_margin_top_negative_15 nd_options_margin_auto nd_options_box_sizing_border_box"></div>
    </div>
    <div class="nd_options_section nd_options_height_15"></div>

    <div class="nd_options_section nd_options_height_30"></div>
    <h1 class="nd_options_font_size_100">'.$nd_options_number.'</h1>
    <div class="nd_options_section nd_options_height_20"></div>
    <h2 class="nd_options_padding_0_40">'.$nd_options_title.'</h2>
    <div class="nd_options_section nd_options_height_20"></div>
    <p class="nd_options_padding_0_40">'.$nd_options_description.'</p>

  </div>
  <!--END FOCUS NUMBER-->

   ';