<?php

$str .= '

<div style="text-align:'.$nd_options_text_align.';" class="nd_options_section">
	<h1 style="padding:'.$nd_options_padding.'; background-color:'.$nd_options_bg_color.'; color:'.$nd_options_number_color.'; font-size:'.$nd_options_number_font_size.'px; line-height:'.$nd_options_number_font_size.'px; " class="nd_options_display_inline_block nd_options_second_font nd_options_counter '.$nd_options_class.' " data-to="'.$nd_options_number.'" data-speed="1000">'.$nd_options_number.'</h1>
</div>

';