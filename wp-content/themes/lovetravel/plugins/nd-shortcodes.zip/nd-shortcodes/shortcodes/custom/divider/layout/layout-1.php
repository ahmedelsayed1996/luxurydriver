<?php


$str .= '
    <div class="nd_options_section nd_options_line_height_0 '.$nd_options_class.' '.$nd_options_align.' ">
        <span style="height:'.$nd_options_height.'; width:'.$nd_options_width.'; background-color:'.$nd_options_color.';" class="nd_options_display_inline_block"></span>
    </div>
   ';