jQuery( function() {
    
    jQuery( "#nd_options_beforeafter_component" ).slider({
      value: 50,
      orientation: "horizontal",
      range: "min",
      animate: true
    });
    
  } );