<?php

  
$str .= '

  <!--START FOCUS NUMBER-->
  <div style="border-right:4px solid '.$nd_options_bg_color.'; '.$nd_options_bg_style.' " class=" '.$nd_options_class.' nd_options_section nd_options_position_relative nd_options_padding_30 nd_options_box_sizing_border_box nd_options_background_size_cover">
    
    <div class="nd_options_position_absolute nd_options_top_30 nd_options_left_30 nd_options_width_50 nd_options_text_align_center">
      <h1 style="color:'.$nd_options_text_color.';" class=" nd_options_font_size_50">'.$nd_options_number.'</h1>
    </div>


    

    <div class="nd_options_section nd_options_padding_left_70 nd_options_box_sizing_border_box">
        <h4 style="color:'.$nd_options_text_color.';">'.$nd_options_title.'</h4>                        
        <div class="nd_options_section nd_options_height_20"></div>
        <p style="color:'.$nd_options_text_color.';">'.$nd_options_description.'</p>
    </div>

  </div>
  <!--END FOCUS NUMBER-->

   ';