<?php
  

$str .= '
	'.$nd_options_align_top.'
	<a style="margin:'.$nd_options_margin.'; border: '.$nd_options_border_width.'px solid '.$nd_options_border_color.'; border-radius:'.$nd_options_border_radius.'px; background-color:'.$nd_options_bg_color.'; padding:'.$nd_options_padding.'; " rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'" class="nicdark_display_inline_block '.$nd_options_align_class.' '.$nd_options_class.' "><img class="nd_options_float_left" alt="" width="'.$nd_options_image_width.'" src="'.$nd_options_image_src[0].'"></a>
	'.$nd_options_align_bottom.'
';

