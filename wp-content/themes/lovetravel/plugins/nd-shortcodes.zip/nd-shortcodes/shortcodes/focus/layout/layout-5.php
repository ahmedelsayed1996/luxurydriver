<?php

  
$str .= '

  <!--START FOCUS-->
  <div class="nd_options_section '.$nd_options_class.' ">
                                            
      <div class="nd_options_section nd_options_position_relative">
      
        <img class="nd_options_section" src="'.$nd_options_image_src[0].'">

        <a style="background-color:'.$nd_options_color.';" class="nd_options_padding_15_20 nd_options_bottom_20 nd_options_right_0 nd_options_color_white nd_options_position_absolute nd_options_line_height_16 nd_options_font_size_16" rel="'.$nd_options_link_rel.'" title="'.$nd_options_link_title.'" target="'.$nd_options_link_target.'" href="'.$nd_options_link_url.'">
          '.$nd_options_title.'
        </a>

      </div>

  </div>
  <!--END FOCUS-->
';