<?php

  
$str .= '

  <!--START FOCUS-->
  <div class="nd_options_section nd_options_background_size_cover '.$nd_options_class.' " style="background-image:url('.$nd_options_image_src[0].');">
                                            
      <div class="nd_options_section nd_options_bg_greydark_alpha_5">
          
          <div class="nd_options_section nd_options_text_align_center">
          
            <div class="nd_options_section nd_options_height_100"></div>
              
            <a rel="'.$nd_options_link_rel.'" title="'.$nd_options_link_title.'" target="'.$nd_options_link_target.'" class="nd_options_color_white" href="'.$nd_options_link_url.'">
              <h1 class="nd_options_margin_0_important nd_options_color_white">
                '.$nd_options_title.'
              </h1>
            </a>
            <div class="nd_options_section nd_options_height_20"></div>
            <h3 class="nd_options_margin_0_important nd_options_text_transform_uppercase nd_options_color_white">'.$nd_options_subtitle.'</h3>

            <div class="nd_options_section nd_options_height_100"></div> 

          </div>

      </div>

  </div>
  <!--END FOCUS-->

   ';