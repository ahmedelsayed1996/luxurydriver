<?php
  

$str .= '

	<!--START FOCUS-->
  	<div class="nd_options_section nd_options_text_align_center nd_options_position_relative '.$nd_options_class.' ">


  		<img alt="" class="nd_options_transition_all_08_ease nd_options_section nd_options_border_radius_3 nd_options_box_shadow_0_7_20_000_015" src="'.$nd_options_image_src[0].'">


      <div class="nd_options_section nd_options_box_sizing_border_box nd_options_padding_20">

        <div class="nd_options_section nd_options_height_10"></div>
        <h2 class=""><strong>'.$nd_options_title.'</strong></h2>
        <div class="nd_options_section nd_options_height_20"></div>
        <p>'.$nd_options_subtitle.'</p>

      </div>


  	</div>
  	<!--END FOCUS-->
	

   ';
