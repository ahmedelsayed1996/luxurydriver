<style type="text/css">
	.widget_nav_menu ul { list-style: none;margin: 0px; padding: 0px; }
    .widget_nav_menu ul li { float:left; width:100%; }
    .widget_nav_menu ul li a { background-color: initial; margin: 0px; padding: 0px; }
    .widget_nav_menu .sub-menu { padding-left: 20px; }
</style>